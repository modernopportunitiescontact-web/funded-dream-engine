"""
app/api/routes/auth.py
----------------------
Login / logout endpoints for the admin dashboard.
POST /auth/login   → validates credentials, sets cookie + returns token
POST /auth/logout  → clears session cookie
GET  /auth/me      → returns current user info (used by frontend to check auth)
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel

from app.api.deps import require_auth
from app.core.security import create_access_token, verify_admin_credentials
from app.core.config import get_settings

router = APIRouter(prefix="/auth", tags=["auth"])
settings = get_settings()

_COOKIE_NAME = "session_token"
_COOKIE_MAX_AGE = settings.SESSION_TTL_MINUTES * 60


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    username: str


@router.post("/login", response_model=LoginResponse)
def login(payload: LoginRequest, response: Response) -> LoginResponse:
    if not verify_admin_credentials(payload.username, payload.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    token = create_access_token(payload.username)

    # Set HttpOnly cookie for browser sessions
    response.set_cookie(
        key=_COOKIE_NAME,
        value=token,
        max_age=_COOKIE_MAX_AGE,
        httponly=True,
        samesite="lax",
        secure=False,  # set True in production with HTTPS
    )

    return LoginResponse(access_token=token, username=payload.username)


@router.post("/logout")
def logout(response: Response) -> dict:
    response.delete_cookie(_COOKIE_NAME)
    return {"ok": True}


@router.get("/me")
def me(username: str = Depends(require_auth)) -> dict:
    return {"username": username, "authenticated": True}


@router.post("/token", response_model=LoginResponse)
def refresh_token(
    response: Response,
    username: str = Depends(require_auth),
) -> LoginResponse:
    """
    Exchange a valid session cookie for a fresh Bearer token.
    Called by the frontend on page load when cookie auth succeeds
    but _token is null (e.g. after browser refresh).
    """
    token = create_access_token(username)
    # Refresh the cookie too
    response.set_cookie(
        key=_COOKIE_NAME,
        value=token,
        max_age=_COOKIE_MAX_AGE,
        httponly=True,
        samesite="lax",
        secure=False,
    )
    return LoginResponse(access_token=token, username=username)
