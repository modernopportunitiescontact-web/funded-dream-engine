"""
app/api/routes/accounts.py
--------------------------
CRUD + test endpoint for MT5 accounts.
All routes require authentication.
"""
from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_auth
from app.schemas.account import (
    AccountCreate, AccountUpdate, AccountOut,
    AccountTestResult, AccountToggleResponse,
)
from app.services.account_service import (
    list_accounts, create_account, update_account,
    toggle_account_enabled, delete_account, test_account_connection,
)

router = APIRouter(prefix="/accounts", tags=["accounts"])


@router.get("", response_model=List[AccountOut])
def get_accounts(
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> List[AccountOut]:
    return list_accounts(db)


@router.post("", response_model=AccountOut, status_code=201)
def post_account(
    payload: AccountCreate,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> AccountOut:
    return create_account(db, payload)


@router.patch("/{account_id}", response_model=AccountOut)
def patch_account(
    account_id: int,
    payload: AccountUpdate,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> AccountOut:
    return update_account(db, account_id, payload)


@router.delete("/{account_id}", status_code=200)
def remove_account(
    account_id: int,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> dict:
    delete_account(db, account_id)
    return {"ok": True, "deleted_id": account_id}


@router.post("/{account_id}/toggle-enabled", response_model=AccountToggleResponse)
def toggle_enabled(
    account_id: int,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> AccountToggleResponse:
    acc = toggle_account_enabled(db, account_id)
    return AccountToggleResponse(id=acc.id, is_enabled=acc.is_enabled)


@router.post("/{account_id}/test", response_model=AccountTestResult)
def test_account(
    account_id: int,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> AccountTestResult:
    return test_account_connection(db, account_id)
