# Route modules are imported directly in app/main.py via include_router()
# Keeping this file empty prevents circular import issues

