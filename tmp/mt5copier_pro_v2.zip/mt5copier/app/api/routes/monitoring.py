"""
app/api/routes/monitoring.py
-----------------------------
Read-only endpoints for operational monitoring:
  GET /health          → lightweight liveness probe
  GET /status          → rich dashboard metrics
  GET /logs            → recent event logs
  GET /mirrors         → position mirror history
  GET /workers         → MT5 worker pool status
"""
from __future__ import annotations

import json
from typing import List

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_auth
from app.copier.engine import get_copier_engine
from app.core.config import get_settings
from app.models.account import Account
from app.models.copier_link import CopierLink
from app.models.event_log import EventLog
from app.models.position_mirror import PositionMirror
from app.mt5.pool import get_worker_pool
from app.schemas.common import HealthResponse, StatusResponse, EventLogOut, PositionMirrorOut

router = APIRouter(tags=["monitoring"])
settings = get_settings()


@router.get("/health", response_model=HealthResponse)
def health(db: Session = Depends(get_db)) -> HealthResponse:
    db_ok = True
    try:
        db.execute(select(func.count()).select_from(Account))
    except Exception:
        db_ok = False

    engine = get_copier_engine()
    return HealthResponse(
        ok=True,
        name=settings.APP_NAME,
        version=settings.APP_VERSION,
        db_ok=db_ok,
        engine_running=engine.is_running,
    )


@router.get("/status", response_model=StatusResponse)
def status(
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> StatusResponse:
    accounts_total = db.scalar(select(func.count()).select_from(Account)) or 0
    accounts_enabled = db.scalar(
        select(func.count()).select_from(Account).where(Account.is_enabled.is_(True))
    ) or 0
    links_total = db.scalar(select(func.count()).select_from(CopierLink)) or 0
    links_active = db.scalar(
        select(func.count()).select_from(CopierLink).where(CopierLink.is_active.is_(True))
    ) or 0
    open_mirrors = db.scalar(
        select(func.count()).select_from(PositionMirror).where(PositionMirror.is_open.is_(True))
    ) or 0

    log_rows = db.scalars(
        select(EventLog).order_by(EventLog.id.desc()).limit(50)
    ).all()

    recent_logs = [
        EventLogOut(
            id=r.id,
            level=r.level,
            message=r.message,
            context=json.loads(r.context_json or "{}"),
            created_at=r.created_at,
        )
        for r in reversed(log_rows)
    ]

    engine = get_copier_engine()
    return StatusResponse(
        accounts_total=accounts_total,
        accounts_enabled=accounts_enabled,
        links_total=links_total,
        links_active=links_active,
        open_mirrors=open_mirrors,
        engine_running=engine.is_running,
        recent_logs=recent_logs,
    )


@router.get("/logs", response_model=List[EventLogOut])
def logs(
    limit: int = Query(default=100, ge=1, le=1000),
    level: str | None = Query(default=None),
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> List[EventLogOut]:
    query = select(EventLog).order_by(EventLog.id.desc()).limit(limit)
    if level:
        query = query.where(EventLog.level == level.upper())

    rows = db.scalars(query).all()
    return [
        EventLogOut(
            id=r.id,
            level=r.level,
            message=r.message,
            context=json.loads(r.context_json or "{}"),
            created_at=r.created_at,
        )
        for r in reversed(rows)
    ]


@router.get("/mirrors", response_model=List[PositionMirrorOut])
def mirrors(
    link_id: int | None = Query(default=None),
    open_only: bool = Query(default=False),
    limit: int = Query(default=200, ge=1, le=2000),
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> List[PositionMirrorOut]:
    query = select(PositionMirror).order_by(PositionMirror.id.desc()).limit(limit)
    if link_id is not None:
        query = query.where(PositionMirror.link_id == link_id)
    if open_only:
        query = query.where(PositionMirror.is_open.is_(True))

    rows = db.scalars(query).all()
    return [
        PositionMirrorOut(
            id=r.id,
            link_id=r.link_id,
            master_ticket=r.master_ticket,
            slave_ticket=r.slave_ticket,
            symbol_master=r.symbol_master,
            symbol_slave=r.symbol_slave,
            volume_master=r.volume_master,
            volume_slave=r.volume_slave,
            side_master=r.side_master,
            is_open=r.is_open,
            opened_at=r.opened_at,
            closed_at=r.closed_at,
            last_error=r.last_error,
        )
        for r in rows
    ]


@router.get("/workers")
def workers(_: str = Depends(require_auth)) -> list:
    """Return MT5 worker pool status for each account."""
    return get_worker_pool().status()


@router.post("/mirrors/{mirror_id}/close")
def force_close_mirror(
    mirror_id: int,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> dict:
    """
    Manually mark a mirror as closed.
    Used when the UI shows a mirror stuck as 'Open' after the position
    was closed externally (e.g. during app downtime).
    Does NOT send any MT5 order — only updates the DB record.
    """
    m = db.get(PositionMirror, mirror_id)
    if m is None:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Mirror not found")
    if not m.is_open:
        return {"ok": True, "message": "Already closed"}
    m.is_open   = False
    m.closed_at = now_utc()
    m.last_error = "manually closed via dashboard"
    db.commit()

    from app.core.logging import log_event
    log_event("INFO", "Mirror manually closed",
              mirror_id=mirror_id,
              master_ticket=m.master_ticket,
              slave_ticket=m.slave_ticket)
    return {"ok": True, "mirror_id": mirror_id}
