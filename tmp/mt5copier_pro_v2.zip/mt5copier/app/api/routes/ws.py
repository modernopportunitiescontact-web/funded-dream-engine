"""
app/api/routes/ws.py
--------------------
WebSocket endpoint for live log broadcasting to the dashboard.
The client sends a token in the first message for authentication.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.core.logging import now_utc
from app.core.security import verify_access_token
from app.core.state import get_app_state

router = APIRouter(tags=["websocket"])
logger = logging.getLogger("mt5copier.ws")


@router.websocket("/ws")
async def websocket_logs(websocket: WebSocket) -> None:
    """
    WebSocket endpoint.
    Protocol:
      1. Client connects.
      2. Server sends {"type": "auth_required"}.
      3. Client sends {"token": "<jwt>"}.
      4. Server validates. On success: {"type": "hello"}.
      5. Server pushes log events as they occur.
      6. Client can send pings; server ignores them.
    """
    state = get_app_state()
    hub = state.ws_hub

    if hub is None:
        await websocket.close(code=1011)
        return

    await websocket.accept()

    # Step 1: request auth
    await websocket.send_json({"type": "auth_required"})

    # Step 2: wait for token
    try:
        msg = await websocket.receive_json()
        token = msg.get("token", "")
    except Exception:
        await websocket.close(code=1008)
        return

    username = verify_access_token(token)
    if username is None:
        await websocket.send_json({"type": "auth_failed", "detail": "Invalid token"})
        await websocket.close(code=1008)
        return

    # Step 3: authenticated — add to hub
    async with hub._lock:
        hub._clients.add(websocket)

    try:
        await websocket.send_json({
            "type": "hello",
            "level": "INFO",
            "message": f"Live log stream connected as {username}",
            "context": {},
            "created_at": now_utc().isoformat(),
        })

        # Keep alive: send ping every 15s, absorb client messages
        import asyncio as _asyncio
        async def _ping_loop():
            while True:
                await _asyncio.sleep(15)
                try:
                    await websocket.send_json({"type": "ping"})
                except Exception:
                    break

        ping_task = _asyncio.create_task(_ping_loop())
        try:
            while True:
                await websocket.receive_text()
        finally:
            ping_task.cancel()

    except WebSocketDisconnect:
        pass
    except Exception as exc:
        logger.debug("WS client error: %s", exc)
    finally:
        await hub.disconnect(websocket)
