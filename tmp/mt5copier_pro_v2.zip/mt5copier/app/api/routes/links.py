"""
app/api/routes/links.py
-----------------------
CRUD + toggle endpoint for copier links.
All routes require authentication.
"""
from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_auth
from app.schemas.copier_link import (
    CopierLinkCreate, CopierLinkUpdate, CopierLinkOut, ToggleResponse,
)
from app.services.link_service import (
    list_links, create_link, update_link,
    toggle_link, delete_link, serialize_link,
)

router = APIRouter(prefix="/links", tags=["links"])


@router.get("", response_model=List[CopierLinkOut])
def get_links(
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> List[CopierLinkOut]:
    links = list_links(db)
    return [serialize_link(lnk) for lnk in links]


@router.post("", response_model=CopierLinkOut, status_code=201)
def post_link(
    payload: CopierLinkCreate,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> CopierLinkOut:
    link = create_link(db, payload)
    return serialize_link(link)


@router.patch("/{link_id}", response_model=CopierLinkOut)
def patch_link(
    link_id: int,
    payload: CopierLinkUpdate,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> CopierLinkOut:
    link = update_link(db, link_id, payload)
    return serialize_link(link)


@router.delete("/{link_id}", status_code=200)
def remove_link(
    link_id: int,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> dict:
    delete_link(db, link_id)
    return {"ok": True, "deleted_id": link_id}


@router.post("/{link_id}/toggle", response_model=ToggleResponse)
def toggle(
    link_id: int,
    db: Session = Depends(get_db),
    _: str = Depends(require_auth),
) -> ToggleResponse:
    link = toggle_link(db, link_id)
    return ToggleResponse(id=link.id, is_active=link.is_active)
