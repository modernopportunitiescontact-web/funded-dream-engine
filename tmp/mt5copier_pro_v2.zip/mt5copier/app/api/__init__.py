# Routes are registered lazily in app/main.py via include_router()
# Do NOT import routes here — it causes premature route registration

