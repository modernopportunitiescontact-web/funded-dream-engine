"""
app/api/deps.py
---------------
FastAPI dependency injection helpers.
  - get_db()        → database session (auto-closed)
  - require_auth()  → validates JWT Bearer token, raises 401 if invalid
"""
from __future__ import annotations

from typing import Generator

from fastapi import Cookie, Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.security import verify_access_token
from app.db.session import SessionLocal

# ── Database session ──────────────────────────────────────────────────────────

def get_db() -> Generator[Session, None, None]:
    """Yield a SQLAlchemy session and close it after the request."""
    with SessionLocal() as db:
        yield db


# ── Auth ──────────────────────────────────────────────────────────────────────

_bearer_scheme = HTTPBearer(auto_error=False)


def require_auth(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
    session_token: str | None = Cookie(default=None, alias="session_token"),
) -> str:
    """
    Validate auth from:
      1. Authorization: Bearer <token>  header  (API clients)
      2. session_token cookie            (browser dashboard)

    Returns the authenticated username.
    Raises HTTP 401 if not authenticated.
    """
    token: str | None = None

    if credentials is not None:
        token = credentials.credentials
    elif session_token is not None:
        token = session_token

    if token is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    username = verify_access_token(token)
    if username is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return username
