"""
app/copier/engine.py
--------------------
CopierEngine v3 — Session-aware, fast, freeze-on-disconnect.

BEHAVIOUR SPEC
==============

1. SESSION SNAPSHOT AT CONNECT TIME
   When the engine starts (or a link becomes active), it takes a
   "session baseline" — the set of master tickets ALREADY OPEN at
   that moment.  These pre-existing positions are NEVER copied.
   Only positions that OPEN AFTER the baseline was taken are copied.

2. FREEZE ON DISCONNECT
   If the app is stopped/crashed, nothing happens on the slave.
   When the app restarts, a new baseline is taken from whatever is
   open on the master at that moment.  Any positions the master opened
   or closed during the downtime are IGNORED — they will never be
   copied or touched on the slave.

3. FAST POLLING
   Default poll interval is 0.5 s (configurable via POLL_INTERVAL_SECONDS).
   The heavy work (MT5 calls) is minimised to two positions_get() per cycle.

4. CLEAN MIRROR LIFECYCLE
   open  → master ticket appears AFTER baseline  → open slave
   close → master ticket disappears              → close slave
   sltp  → master SL/TP changes                  → update slave
   disconnect-then-reconnect → new baseline, old mirrors cleared
"""
from __future__ import annotations

import json
import logging
import threading
from dataclasses import dataclass, field
from datetime import timedelta
from typing import Dict, Optional, Set

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.core.config import get_settings
from app.core.logging import log_event, now_utc
from datetime import timezone as _UTC
from app.db.session import SessionLocal
from app.models.account import Account
from app.models.copier_link import CopierLink
from app.models.position_mirror import PositionMirror
from app.mt5.adapter import MT5Adapter, PositionSnapshot
from app.mt5.pool import get_worker_pool

logger = logging.getLogger("mt5copier.engine")
settings = get_settings()

try:
    import MetaTrader5 as _mt5
    _BUY     = _mt5.ORDER_TYPE_BUY
    _SELL    = _mt5.ORDER_TYPE_SELL
    _POS_BUY = _mt5.POSITION_TYPE_BUY
except ImportError:
    _BUY = 0; _SELL = 1; _POS_BUY = 0


# ── Helpers ───────────────────────────────────────────────────────────────────

def _map_side(pos_type: int, reverse: bool) -> int:
    side = _BUY if pos_type == _POS_BUY else _SELL
    if reverse:
        return _SELL if side == _BUY else _BUY
    return side


def _almost_equal(a: Optional[float], b: Optional[float], eps: float = 1e-7) -> bool:
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    return abs(a - b) <= eps


def _as_utc(dt) -> object:
    """Ensure a datetime is timezone-aware UTC (handles SQLite naive returns)."""
    if dt is None:
        return dt
    if hasattr(dt, 'tzinfo') and dt.tzinfo is None:
        return dt.replace(tzinfo=_UTC.utc)
    return dt


def _is_hard_error(msg: str) -> bool:
    """MT5 error codes that won't self-resolve → trigger link backoff."""
    codes = ("10027", "10018", "10016", "10014", "10013")
    return any(c in msg for c in codes)


# ── Plain-data snapshots (safe after session close) ───────────────────────────

@dataclass
class _LinkConfig:
    id: int
    is_active: bool
    master_account_id: int
    slave_account_id: int
    symbol_map: Dict[str, str]
    lot_multiplier: float
    fixed_lot: Optional[float]
    copy_sl: bool
    copy_tp: bool
    reverse_side: bool
    comment_prefix: str
    next_retry_at: Optional[object]


@dataclass
class _MirrorRow:
    id: int
    master_ticket: int
    slave_ticket: int


# ── Per-link session state ─────────────────────────────────────────────────────

@dataclass
class _LinkSession:
    """
    Tracks the runtime state for one active link.
    Reset every time the link is (re)activated.
    """
    # Tickets open on master at the moment this session started.
    # These are NEVER copied — they pre-existed the session.
    baseline_tickets: Set[int] = field(default_factory=set)
    # Whether we have taken the baseline yet this session
    baseline_taken: bool = False


# ── Engine ─────────────────────────────────────────────────────────────────────

class CopierEngine:

    def __init__(self) -> None:
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        # Per-link session state keyed by link_id
        self._sessions: Dict[int, _LinkSession] = {}
        self._sessions_lock = threading.Lock()

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        # Clear all session state on (re)start — fresh baselines will be taken
        with self._sessions_lock:
            self._sessions.clear()
        self._thread = threading.Thread(
            target=self._run, name="copier-engine", daemon=True
        )
        self._thread.start()
        logger.info("CopierEngine started.")

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=10)
            self._thread = None
        logger.info("CopierEngine stopped.")

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def reset_link_session(self, link_id: int) -> None:
        """Force a fresh baseline on next poll (called on link resume/toggle)."""
        with self._sessions_lock:
            self._sessions.pop(link_id, None)
        logger.info("Session reset for link %d", link_id)

    # ── Main loop ──────────────────────────────────────────────────────────────

    def _run(self) -> None:
        log_event("INFO", "Copier engine loop started")
        while not self._stop_event.is_set():
            try:
                self._poll_all_links()
            except Exception as exc:
                logger.error("Engine loop error: %s", exc, exc_info=True)
            self._stop_event.wait(settings.POLL_INTERVAL_SECONDS)
        log_event("INFO", "Copier engine loop stopped")

    def _poll_all_links(self) -> None:
        with SessionLocal() as db:
            rows = db.scalars(
                select(CopierLink)
                .where(CopierLink.is_active.is_(True))
                .order_by(CopierLink.id.asc())
            ).all()
            links = [
                _LinkConfig(
                    id=r.id,
                    is_active=r.is_active,
                    master_account_id=r.master_account_id,
                    slave_account_id=r.slave_account_id,
                    symbol_map=json.loads(r.symbol_map_json or "{}"),
                    lot_multiplier=r.lot_multiplier,
                    fixed_lot=r.fixed_lot,
                    copy_sl=r.copy_sl,
                    copy_tp=r.copy_tp,
                    reverse_side=r.reverse_side,
                    comment_prefix=r.comment_prefix,
                    next_retry_at=r.next_retry_at,
                )
                for r in rows
            ]

        now = now_utc()
        # Filter links ready to run
        ready_links = [
            lnk for lnk in links
            if lnk.next_retry_at is None
            or _as_utc(lnk.next_retry_at) <= now
        ]

        if not ready_links:
            return

        # Sequential execution — required because _G (global MT5 lock)
        # serialises all MT5 calls anyway. Parallel threads would just
        # queue up behind _G and cause HTTP request timeouts.
        for lnk in ready_links:
            try:
                self._sync_link(lnk)
            except Exception as exc:
                self._mark_link_error(lnk.id, str(exc))

    # ── Link sync ──────────────────────────────────────────────────────────────

    def _sync_link(self, link: _LinkConfig) -> None:
        pool = get_worker_pool()

        # Load account info
        with SessionLocal() as db:
            master_acc = db.get(Account, link.master_account_id)
            slave_acc  = db.get(Account, link.slave_account_id)
            if master_acc is None or slave_acc is None:
                raise RuntimeError("Master or slave account not found")
            if not master_acc.is_enabled or not slave_acc.is_enabled:
                raise RuntimeError("Master or slave account is disabled")
            master_id = master_acc.id
            slave_id  = slave_acc.id

        master_worker = pool.get_worker(master_id)
        slave_worker  = pool.get_worker(slave_id)

        # Auto-restart workers that never started or crashed
        for acc_id in ([master_id] if (master_worker is None or not master_worker.is_alive) else []) + \
                      ([slave_id]  if (slave_worker  is None or not slave_worker.is_alive)  else []):
            try:
                from app.core.security import decrypt_secret
                import time
                with SessionLocal() as db:
                    acc = db.get(Account, acc_id)
                    if acc and acc.is_enabled:
                        pw = decrypt_secret(acc.password_enc)
                        pool.start_worker(
                            account_id=acc.id, login=acc.login,
                            password=pw, server=acc.server,
                            terminal_path=acc.terminal_path,
                        )
                        time.sleep(0.5)
            except Exception as exc:
                logger.warning("Auto-restart worker %d failed: %s", acc_id, exc)

        master_worker = pool.get_worker(master_id)
        slave_worker  = pool.get_worker(slave_id)

        if master_worker is None:
            raise RuntimeError(f"No worker for master account {master_id}")
        if slave_worker is None:
            raise RuntimeError(f"No worker for slave account {slave_id}")

        timeout = settings.MT5_OPERATION_TIMEOUT_SECONDS

        # ── Fetch master positions ─────────────────────────────────────────────
        try:
            master_positions: Dict[int, PositionSnapshot] = {
                p.ticket: p
                for p in master_worker.submit(MT5Adapter.positions_all).result(timeout=timeout)
            }
        except Exception as exc:
            raise RuntimeError(f"Master positions_get failed: {exc}") from exc

        # ── Take baseline on first poll of this session ────────────────────────
        with self._sessions_lock:
            session = self._sessions.get(link.id)
            if session is None or not session.baseline_taken:
                # First time seeing this link this session:
                # record all currently-open master tickets as pre-existing.
                # These will NEVER be copied.
                session = _LinkSession(
                    baseline_tickets=set(master_positions.keys()),
                    baseline_taken=True,
                )
                self._sessions[link.id] = session
                log_event(
                    "INFO",
                    "Session baseline taken",
                    link_id=link.id,
                    pre_existing_tickets=list(session.baseline_tickets),
                    count=len(session.baseline_tickets),
                )
                # Also close any DB open mirrors for tickets that are no longer
                # open on master (they may have closed during our downtime)
                self._reconcile_stale_mirrors(link.id, set(master_positions.keys()))
                # Mark link success and return — start copying fresh next cycle
                _mark_link_ok(link.id)
                return

            baseline_tickets = session.baseline_tickets

        # ── Fetch slave positions ──────────────────────────────────────────────
        try:
            slave_positions: Dict[int, PositionSnapshot] = {
                p.ticket: p
                for p in slave_worker.submit(MT5Adapter.positions_all).result(timeout=timeout)
            }
        except Exception as exc:
            raise RuntimeError(f"Slave positions_get failed: {exc}") from exc

        # ── Load open mirrors from DB ──────────────────────────────────────────
        with SessionLocal() as db:
            mirror_rows = db.scalars(
                select(PositionMirror)
                .where(
                    PositionMirror.link_id == link.id,
                    PositionMirror.is_open.is_(True),
                )
            ).all()
            open_mirrors: Dict[int, _MirrorRow] = {
                m.master_ticket: _MirrorRow(
                    id=m.id,
                    master_ticket=m.master_ticket,
                    slave_ticket=m.slave_ticket,
                )
                for m in mirror_rows
            }

        # ── Close slave positions whose master has closed ──────────────────────
        for master_ticket, mirror in list(open_mirrors.items()):
            if master_ticket not in master_positions:
                # Master closed this position → close slave
                slave_pos = slave_positions.get(mirror.slave_ticket)
                if slave_pos is not None:
                    self._close_slave(slave_worker, mirror, link.id)
                else:
                    # Already closed on slave side too
                    _mark_mirror_closed(mirror.id, "both sides closed")

        # ── Open new mirrors for NEW master positions ──────────────────────────
        already_mirrored: Set[int] = set(open_mirrors.keys())

        for ticket, master_pos in master_positions.items():
            # Skip pre-existing positions (baseline)
            if ticket in baseline_tickets:
                continue
            # Skip already-mirrored
            if ticket in already_mirrored:
                continue
            # This is a genuinely NEW position → copy it
            self._open_mirror(slave_worker, link, master_pos)

        # ── Sync SL/TP on active mirrors ───────────────────────────────────────
        for master_ticket, mirror in open_mirrors.items():
            master_pos = master_positions.get(master_ticket)
            slave_pos  = slave_positions.get(mirror.slave_ticket)
            if master_pos is None or slave_pos is None:
                continue
            self._maybe_sync_sltp(slave_worker, mirror, master_pos, slave_pos, link)

        # ── Update account status + mark link success ──────────────────────────
        with SessionLocal() as db:
            _touch_account(db, master_id, "polling")
            _touch_account(db, slave_id, "polling")
        _mark_link_ok(link.id)

    # ── Reconcile stale DB mirrors after reconnect ────────────────────────────

    def _reconcile_stale_mirrors(
        self, link_id: int, live_master_tickets: Set[int]
    ) -> None:
        """
        After reconnect/baseline: mark DB open mirrors as closed if:
        - master ticket no longer open on master, OR
        - master ticket is in baseline (pre-existing, will never be re-copied)
        This ensures mirrors from previous sessions are cleaned up correctly.
        """
        with self._sessions_lock:
            session = self._sessions.get(link_id)
            baseline = session.baseline_tickets if session else set()

        with SessionLocal() as db:
            mirrors = db.scalars(
                select(PositionMirror)
                .where(
                    PositionMirror.link_id == link_id,
                    PositionMirror.is_open.is_(True),
                )
            ).all()
            stale = [
                m for m in mirrors
                if m.master_ticket not in live_master_tickets
                # Also close mirrors for baseline tickets that are
                # no longer tracked (position closed while app was down)
            ]
            for m in stale:
                m.is_open    = False
                m.closed_at  = now_utc()
                m.last_error = "closed during app disconnect"
            if stale:
                db.commit()
                log_event(
                    "INFO",
                    "Stale mirrors cleared after reconnect",
                    link_id=link_id,
                    count=len(stale),
                    tickets=[m.master_ticket for m in stale],
                )

    # ── Open mirror ────────────────────────────────────────────────────────────

    def _open_mirror(
        self,
        slave_worker,
        link: _LinkConfig,
        master_pos: PositionSnapshot,
    ) -> None:
        slave_symbol = link.symbol_map.get(master_pos.symbol, master_pos.symbol)
        slave_side   = _map_side(master_pos.type, link.reverse_side)
        slave_volume = (
            link.fixed_lot
            if link.fixed_lot is not None
            else master_pos.volume * link.lot_multiplier
        )
        slave_sl = master_pos.sl if (link.copy_sl and master_pos.sl > 0) else None
        slave_tp = master_pos.tp if (link.copy_tp and master_pos.tp > 0) else None
        comment  = f"{link.comment_prefix}:{master_pos.ticket}"

        _sym = slave_symbol; _side = slave_side; _vol = slave_volume
        _sl  = slave_sl;     _tp   = slave_tp;   _cmt = comment
        _magic = settings.MAGIC_NUMBER; _dev = settings.DEFAULT_DEVIATION

        timeout = settings.MT5_OPERATION_TIMEOUT_SECONDS
        try:
            slave_ticket: int = slave_worker.submit(
                lambda: MT5Adapter.send_market_order(
                    symbol=_sym, order_type=_side, volume=_vol,
                    sl=_sl, tp=_tp, comment=_cmt,
                    magic=_magic, deviation=_dev,
                )
            ).result(timeout=timeout)
        except Exception as exc:
            err = str(exc)
            log_event(
                "ERROR", "Failed to open slave position",
                link_id=link.id,
                master_ticket=master_pos.ticket,
                symbol=master_pos.symbol,
                error=err,
            )
            if _is_hard_error(err):
                raise RuntimeError(err)
            return

        try:
            with SessionLocal() as db:
                db.add(PositionMirror(
                    link_id=link.id,
                    master_ticket=master_pos.ticket,
                    slave_ticket=slave_ticket,
                    symbol_master=master_pos.symbol,
                    symbol_slave=slave_symbol,
                    volume_master=master_pos.volume,
                    volume_slave=slave_volume,
                    side_master=master_pos.type,
                    is_open=True,
                ))
                db.commit()
        except IntegrityError:
            logger.warning(
                "Duplicate mirror prevented link=%d ticket=%d",
                link.id, master_pos.ticket,
            )
            return

        log_event(
            "INFO", "Opened mirror position",
            link_id=link.id,
            master_ticket=master_pos.ticket,
            slave_ticket=slave_ticket,
            symbol=master_pos.symbol,
            volume_master=master_pos.volume,
            volume_slave=slave_volume,
        )

    # ── Close slave position ───────────────────────────────────────────────────

    def _close_slave(
        self,
        slave_worker,
        mirror: _MirrorRow,
        link_id: int,
    ) -> None:
        ticket = mirror.slave_ticket
        _magic = settings.MAGIC_NUMBER
        _dev   = settings.DEFAULT_DEVIATION
        timeout = settings.MT5_OPERATION_TIMEOUT_SECONDS

        try:
            slave_worker.submit(
                lambda: MT5Adapter.close_position(
                    ticket=ticket, deviation=_dev, magic=_magic
                )
            ).result(timeout=timeout)
        except Exception as exc:
            log_event(
                "ERROR", "Failed to close slave position",
                link_id=link_id, slave_ticket=mirror.slave_ticket, error=str(exc),
            )
            return

        _mark_mirror_closed(mirror.id)
        log_event(
            "INFO", "Closed mirror position",
            link_id=link_id,
            master_ticket=mirror.master_ticket,
            slave_ticket=mirror.slave_ticket,
        )

    # ── SL/TP sync ─────────────────────────────────────────────────────────────

    def _maybe_sync_sltp(
        self,
        slave_worker,
        mirror: _MirrorRow,
        master_pos: PositionSnapshot,
        slave_pos: PositionSnapshot,
        link: _LinkConfig,
    ) -> None:
        wanted_sl  = master_pos.sl if (link.copy_sl and master_pos.sl > 0) else None
        wanted_tp  = master_pos.tp if (link.copy_tp and master_pos.tp > 0) else None
        current_sl = slave_pos.sl  if slave_pos.sl > 0 else None
        current_tp = slave_pos.tp  if slave_pos.tp > 0 else None

        # Nothing to sync if master has no SL/TP set
        if wanted_sl is None and wanted_tp is None:
            return

        if _almost_equal(current_sl, wanted_sl) and _almost_equal(current_tp, wanted_tp):
            return

        ticket = mirror.slave_ticket
        _sl = wanted_sl; _tp = wanted_tp
        timeout = settings.MT5_OPERATION_TIMEOUT_SECONDS

        try:
            slave_worker.submit(
                lambda: MT5Adapter.modify_sl_tp(ticket=ticket, sl=_sl, tp=_tp)
            ).result(timeout=timeout)
        except Exception as exc:
            log_event(
                "ERROR", "Failed to update SL/TP",
                link_id=link.id, slave_ticket=mirror.slave_ticket, error=str(exc),
            )
            return

        log_event(
            "INFO", "Updated SL/TP",
            link_id=link.id,
            master_ticket=mirror.master_ticket,
            slave_ticket=mirror.slave_ticket,
            sl=wanted_sl, tp=wanted_tp,
        )

    # ── Error backoff ──────────────────────────────────────────────────────────

    def _mark_link_error(self, link_id: int, message: str) -> None:
        try:
            with SessionLocal() as db:
                link = db.get(CopierLink, link_id)
                if link is None:
                    return
                link.retry_count  = (link.retry_count or 0) + 1
                cooldown = min(
                    settings.LINK_ERROR_COOLDOWN_SECONDS
                    * (2 ** max(0, link.retry_count - 1)),
                    settings.LINK_ERROR_COOLDOWN_MAX_SECONDS,
                )
                link.last_error    = message[:500]
                link.last_run_at   = now_utc()
                link.next_retry_at = now_utc() + timedelta(seconds=cooldown)
                db.commit()
        except Exception as exc:
            logger.error("Failed to persist link error: %s", exc)
        log_event("ERROR", "Link sync failed", link_id=link_id, error=message)


# ── Module-level helpers ───────────────────────────────────────────────────────

def _touch_account(db, account_id: int, status: str) -> None:
    acc = db.get(Account, account_id)
    if acc:
        acc.last_status  = status[:255]
        acc.last_seen_at = now_utc()
        db.commit()


def _mark_mirror_closed(mirror_id: int, reason: Optional[str] = None) -> None:
    with SessionLocal() as db:
        m = db.get(PositionMirror, mirror_id)
        if m:
            m.is_open   = False
            m.closed_at = now_utc()
            if reason:
                m.last_error = reason[:500]
            db.commit()


def _mark_link_ok(link_id: int) -> None:
    with SessionLocal() as db:
        lnk = db.get(CopierLink, link_id)
        if lnk:
            lnk.last_run_at   = now_utc()
            lnk.last_error    = None
            lnk.retry_count   = 0
            lnk.next_retry_at = None
            db.commit()


# ── Singleton ──────────────────────────────────────────────────────────────────

_engine_instance: Optional[CopierEngine] = None
_engine_lock = threading.Lock()


def get_copier_engine() -> CopierEngine:
    global _engine_instance
    if _engine_instance is None:
        with _engine_lock:
            if _engine_instance is None:
                _engine_instance = CopierEngine()
    return _engine_instance
