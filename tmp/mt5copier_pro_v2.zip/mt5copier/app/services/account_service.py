"""
app/services/account_service.py
---------------------------------
Business logic for Account CRUD and MT5 connection testing.
Routes stay thin — all logic lives here.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.logging import log_event, now_utc
from app.core.security import decrypt_secret, encrypt_secret
from app.models.account import Account
from app.models.copier_link import CopierLink
from app.mt5.adapter import MT5Adapter, AccountSnapshot
from app.mt5.pool import get_worker_pool
from app.schemas.account import AccountCreate, AccountUpdate, AccountTestResult

logger = logging.getLogger("mt5copier.services.account")


def list_accounts(db: Session) -> List[Account]:
    return list(db.scalars(select(Account).order_by(Account.id.asc())).all())


def get_account_or_404(db: Session, account_id: int) -> Account:
    acc = db.get(Account, account_id)
    if acc is None:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Account not found")
    return acc


def create_account(db: Session, payload: AccountCreate) -> Account:
    name = payload.name.strip()
    server = payload.server.strip()

    existing = db.scalar(select(Account).where(Account.name == name))
    if existing is not None:
        from fastapi import HTTPException
        raise HTTPException(status_code=409, detail=f"Account name '{name}' already exists")

    account = Account(
        name=name,
        login=payload.login,
        server=server,
        password_enc=encrypt_secret(payload.password),
        terminal_path=payload.terminal_path.strip() if payload.terminal_path else None,
        role_hint=payload.role_hint,
        is_enabled=payload.is_enabled,
        last_status="saved — not yet tested",
    )
    try:
        db.add(account)
        db.commit()
        db.refresh(account)
    except IntegrityError:
        db.rollback()
        from fastapi import HTTPException
        raise HTTPException(status_code=409, detail="Account name already exists")

    # Start a worker for the new account if it's enabled
    if account.is_enabled:
        try:
            get_worker_pool().start_worker(
                account_id=account.id,
                login=account.login,
                password=payload.password,
                server=account.server,
                terminal_path=account.terminal_path,
            )
        except Exception as exc:
            logger.warning("Could not start worker for new account %d: %s", account.id, exc)

    log_event(
        "INFO", "Account created",
        account_id=account.id, name=account.name, login=account.login, server=account.server,
    )
    return account


def update_account(db: Session, account_id: int, payload: AccountUpdate) -> Account:
    account = get_account_or_404(db, account_id)

    if payload.name is not None:
        account.name = payload.name.strip()
    if payload.server is not None:
        account.server = payload.server.strip()
    if payload.password is not None:
        account.password_enc = encrypt_secret(payload.password)
    if payload.terminal_path is not None:
        account.terminal_path = payload.terminal_path.strip() or None
    if payload.role_hint is not None:
        account.role_hint = payload.role_hint
    if payload.is_enabled is not None:
        account.is_enabled = payload.is_enabled

    try:
        db.commit()
        db.refresh(account)
    except IntegrityError:
        db.rollback()
        from fastapi import HTTPException
        raise HTTPException(status_code=409, detail="Account name already exists")

    # Restart worker to pick up credential changes
    pool = get_worker_pool()
    if account.is_enabled:
        try:
            password = decrypt_secret(account.password_enc)
            pool.restart_worker(
                account_id=account.id,
                login=account.login,
                password=password,
                server=account.server,
                terminal_path=account.terminal_path,
            )
        except Exception as exc:
            logger.warning("Could not restart worker for account %d: %s", account.id, exc)
    else:
        pool.stop_worker(account.id)

    log_event("INFO", "Account updated", account_id=account.id, name=account.name)
    return account


def toggle_account_enabled(db: Session, account_id: int) -> Account:
    account = get_account_or_404(db, account_id)
    account.is_enabled = not account.is_enabled
    account.last_seen_at = now_utc()
    if not account.is_enabled:
        account.last_status = "disabled by admin"
    db.commit()

    pool = get_worker_pool()
    if account.is_enabled:
        try:
            password = decrypt_secret(account.password_enc)
            pool.start_worker(
                account_id=account.id,
                login=account.login,
                password=password,
                server=account.server,
                terminal_path=account.terminal_path,
            )
        except Exception as exc:
            logger.warning("Could not start worker for account %d: %s", account.id, exc)
    else:
        pool.stop_worker(account.id)

    log_event(
        "INFO", "Account toggled",
        account_id=account.id, name=account.name, is_enabled=account.is_enabled,
    )
    return account


def delete_account(db: Session, account_id: int) -> None:
    account = get_account_or_404(db, account_id)

    linked = db.scalar(
        select(CopierLink.id).where(
            (CopierLink.master_account_id == account_id)
            | (CopierLink.slave_account_id == account_id)
        ).limit(1)
    )
    if linked is not None:
        from fastapi import HTTPException
        raise HTTPException(
            status_code=400,
            detail="Cannot delete account while it is used by one or more copier links. "
                   "Delete the links first.",
        )

    name = account.name
    get_worker_pool().stop_worker(account_id)
    db.delete(account)
    db.commit()
    log_event("INFO", "Account deleted", account_id=account_id, name=name)


def test_account_connection(db: Session, account_id: int) -> AccountTestResult:
    account = get_account_or_404(db, account_id)

    pool = get_worker_pool()
    worker = pool.get_worker(account_id)

    # Ensure worker is running for this account
    if worker is None or not worker.is_alive:
        try:
            password = decrypt_secret(account.password_enc)
            worker = pool.start_worker(
                account_id=account.id,
                login=account.login,
                password=password,
                server=account.server,
                terminal_path=account.terminal_path,
            )
        except Exception as exc:
            _update_status(db, account, f"error: {exc}")
            return AccountTestResult(ok=False, error=str(exc))

    # Submit a full test through the worker (uses global lock + initialize)
    timeout = 25.0
    login = account.login
    password = decrypt_secret(account.password_enc)
    server = account.server
    terminal_path = account.terminal_path

    def _full_test():
        """Run inside worker thread with global lock held."""
        from app.mt5.worker import _G, _do_init, _safe_shutdown
        # _G is already held by the worker's _execute method
        # so we just call MT5 directly here
        return MT5Adapter.account_snapshot()

    try:
        snapshot = worker.submit(_full_test).result(timeout=timeout)
    except Exception as exc:
        error_msg = str(exc)
        _update_status(db, account, f"error: {error_msg}")
        log_event("ERROR", "Account test failed",
                  account_id=account_id, error=error_msg)
        return AccountTestResult(ok=False, error=error_msg)

    _update_status(db, account, f"connected: {snapshot.name}")
    log_event(
        "INFO", "Account test OK",
        account_id=account_id, login=snapshot.login, server=snapshot.server,
    )
    return AccountTestResult(
        ok=True,
        login=snapshot.login,
        name=snapshot.name,
        server=snapshot.server,
        balance=snapshot.balance,
        equity=snapshot.equity,
        currency=snapshot.currency,
    )


def _update_status(db: Session, account: Account, status: str) -> None:
    account.last_status = status[:255]
    account.last_seen_at = now_utc()
    db.commit()
