"""
app/services/link_service.py
-----------------------------
Business logic for CopierLink CRUD.
"""
from __future__ import annotations

import json
import logging
from typing import List

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.logging import log_event, now_utc, json_dumps
from app.models.account import Account
from app.models.copier_link import CopierLink
from app.schemas.copier_link import CopierLinkCreate, CopierLinkUpdate

logger = logging.getLogger("mt5copier.services.link")


def list_links(db: Session) -> List[CopierLink]:
    return list(db.scalars(select(CopierLink).order_by(CopierLink.id.asc())).all())


def get_link_or_404(db: Session, link_id: int) -> CopierLink:
    link = db.get(CopierLink, link_id)
    if link is None:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Copier link not found")
    return link


def create_link(db: Session, payload: CopierLinkCreate) -> CopierLink:
    from fastapi import HTTPException

    if payload.master_account_id == payload.slave_account_id:
        raise HTTPException(
            status_code=400, detail="Master and slave cannot be the same account"
        )

    master = db.get(Account, payload.master_account_id)
    slave = db.get(Account, payload.slave_account_id)
    if master is None or slave is None:
        raise HTTPException(status_code=404, detail="Master or slave account not found")

    name = payload.name.strip()
    existing = db.scalar(select(CopierLink).where(CopierLink.name == name))
    if existing is not None:
        raise HTTPException(status_code=409, detail=f"Link name '{name}' already exists")

    # Check for duplicate master→slave pair
    dup_pair = db.scalar(
        select(CopierLink).where(
            CopierLink.master_account_id == payload.master_account_id,
            CopierLink.slave_account_id == payload.slave_account_id,
        )
    )
    if dup_pair is not None:
        raise HTTPException(
            status_code=409,
            detail="A link between this master and slave already exists",
        )

    link = CopierLink(
        name=name,
        master_account_id=payload.master_account_id,
        slave_account_id=payload.slave_account_id,
        is_active=payload.is_active,
        symbol_map_json=json_dumps(payload.symbol_map),
        lot_multiplier=payload.lot_multiplier,
        fixed_lot=payload.fixed_lot,
        copy_sl=payload.copy_sl,
        copy_tp=payload.copy_tp,
        reverse_side=payload.reverse_side,
        comment_prefix=payload.comment_prefix,
        retry_count=0,
        next_retry_at=None,
    )
    try:
        db.add(link)
        db.commit()
        db.refresh(link)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Link name or pair already exists")

    log_event(
        "INFO", "Link created",
        link_id=link.id, name=link.name,
        master_account_id=link.master_account_id,
        slave_account_id=link.slave_account_id,
    )
    return link


def update_link(db: Session, link_id: int, payload: CopierLinkUpdate) -> CopierLink:
    link = get_link_or_404(db, link_id)

    if payload.name is not None:
        link.name = payload.name.strip()
    if payload.lot_multiplier is not None:
        link.lot_multiplier = payload.lot_multiplier
    if payload.fixed_lot is not None:
        link.fixed_lot = payload.fixed_lot
    if payload.symbol_map is not None:
        link.symbol_map_json = json_dumps(payload.symbol_map)
    if payload.copy_sl is not None:
        link.copy_sl = payload.copy_sl
    if payload.copy_tp is not None:
        link.copy_tp = payload.copy_tp
    if payload.reverse_side is not None:
        link.reverse_side = payload.reverse_side
    if payload.comment_prefix is not None:
        link.comment_prefix = payload.comment_prefix

    try:
        db.commit()
        db.refresh(link)
    except IntegrityError:
        db.rollback()
        from fastapi import HTTPException
        raise HTTPException(status_code=409, detail="Link name already in use")

    log_event("INFO", "Link updated", link_id=link.id, name=link.name)
    return link


def toggle_link(db: Session, link_id: int) -> CopierLink:
    link = get_link_or_404(db, link_id)
    link.is_active = not link.is_active
    # Reset error state on resume
    link.last_error = None
    link.retry_count = 0
    link.next_retry_at = None
    db.commit()

    # When resuming, force a fresh session baseline so pre-existing
    # master positions are not copied again
    if link.is_active:
        try:
            from app.copier.engine import get_copier_engine
            get_copier_engine().reset_link_session(link.id)
        except Exception as exc:
            logger.warning("Could not reset link session: %s", exc)

    log_event(
        "INFO", "Link toggled",
        link_id=link.id, name=link.name, is_active=link.is_active,
    )
    return link


def delete_link(db: Session, link_id: int) -> None:
    link = get_link_or_404(db, link_id)
    name = link.name
    db.delete(link)
    db.commit()
    log_event("INFO", "Link deleted", link_id=link_id, name=name)


def serialize_link(link: CopierLink) -> dict:
    return {
        "id": link.id,
        "name": link.name,
        "master_account_id": link.master_account_id,
        "slave_account_id": link.slave_account_id,
        "lot_multiplier": link.lot_multiplier,
        "fixed_lot": link.fixed_lot,
        "symbol_map": json.loads(link.symbol_map_json or "{}"),
        "copy_sl": link.copy_sl,
        "copy_tp": link.copy_tp,
        "reverse_side": link.reverse_side,
        "comment_prefix": link.comment_prefix,
        "is_active": link.is_active,
        "last_run_at": link.last_run_at,
        "last_error": link.last_error,
        "retry_count": link.retry_count,
        "next_retry_at": link.next_retry_at,
        "created_at": link.created_at,
    }
