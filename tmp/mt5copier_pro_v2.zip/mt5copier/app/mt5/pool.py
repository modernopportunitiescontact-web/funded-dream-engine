"""
app/mt5/pool.py
---------------
WorkerPool manages the lifecycle of all AccountWorker instances.

On startup it loads all enabled accounts from the DB and starts a worker
for each. Workers can be added/removed at runtime when accounts are
created, deleted, enabled, or disabled.

The copier engine uses the pool to get a worker for a given account_id
and submit MT5 tasks to it.
"""
from __future__ import annotations

import logging
import threading
from typing import Dict, List, Optional

from app.mt5.worker import AccountWorker

logger = logging.getLogger("mt5copier.pool")


class WorkerPool:
    """Thread-safe registry of per-account MT5 workers."""

    def __init__(self, operation_timeout: float = 10.0) -> None:
        self._workers: Dict[int, AccountWorker] = {}
        self._lock = threading.Lock()
        self._operation_timeout = operation_timeout

    def start_worker(
        self,
        account_id: int,
        login: int,
        password: str,
        server: str,
        terminal_path: Optional[str] = None,
    ) -> AccountWorker:
        """
        Create and start a worker for the given account.
        If one already exists and is alive, return it unchanged.
        """
        with self._lock:
            existing = self._workers.get(account_id)
            if existing is not None and existing.is_alive:
                return existing

            worker = AccountWorker(
                account_id=account_id,
                login=login,
                password=password,
                server=server,
                terminal_path=terminal_path,
                operation_timeout=self._operation_timeout,
            )
            worker.start()
            self._workers[account_id] = worker
            logger.info("Pool: started worker for account_id=%d", account_id)
            return worker

    def stop_worker(self, account_id: int) -> None:
        """Stop and remove the worker for the given account."""
        with self._lock:
            worker = self._workers.pop(account_id, None)
        if worker is not None:
            worker.stop()
            logger.info("Pool: stopped worker for account_id=%d", account_id)

    def restart_worker(
        self,
        account_id: int,
        login: int,
        password: str,
        server: str,
        terminal_path: Optional[str] = None,
    ) -> AccountWorker:
        """Stop old worker (if any) and start a fresh one."""
        self.stop_worker(account_id)
        return self.start_worker(account_id, login, password, server, terminal_path)

    def get_worker(self, account_id: int) -> Optional[AccountWorker]:
        with self._lock:
            return self._workers.get(account_id)

    def stop_all(self) -> None:
        with self._lock:
            ids = list(self._workers.keys())
        for account_id in ids:
            self.stop_worker(account_id)
        logger.info("Pool: all workers stopped.")

    def status(self) -> List[Dict]:
        with self._lock:
            return [
                {
                    "account_id": acc_id,
                    "alive": w.is_alive,
                    "connected": w.is_connected,
                    "last_error": w.last_error,
                }
                for acc_id, w in self._workers.items()
            ]

    def bootstrap_from_db(self) -> None:
        """
        Load all enabled accounts from the database and start their workers.
        Workers are started one at a time with a short delay between each
        to avoid overwhelming the MT5 terminal at startup.
        """
        import time
        from app.db.session import SessionLocal
        from app.models.account import Account
        from app.core.security import decrypt_secret

        with SessionLocal() as db:
            accounts = db.query(Account).filter(Account.is_enabled.is_(True)).all()

        for i, acc in enumerate(accounts):
            try:
                password = decrypt_secret(acc.password_enc)
                self.start_worker(
                    account_id=acc.id,
                    login=acc.login,
                    password=password,
                    server=acc.server,
                    terminal_path=acc.terminal_path,
                )
                # Small delay between workers to avoid MT5 DLL race at startup
                if i < len(accounts) - 1:
                    time.sleep(0.5)
            except Exception as exc:
                logger.error(
                    "Pool: failed to start worker for account_id=%d: %s", acc.id, exc
                )

        logger.info("Pool: bootstrapped %d workers from DB.", len(accounts))


# ── Singleton ─────────────────────────────────────────────────────────────────

_pool_instance: Optional[WorkerPool] = None
_pool_lock = threading.Lock()


def get_worker_pool() -> WorkerPool:
    global _pool_instance
    if _pool_instance is None:
        with _pool_lock:
            if _pool_instance is None:
                from app.core.config import get_settings
                settings = get_settings()
                _pool_instance = WorkerPool(
                    operation_timeout=settings.MT5_OPERATION_TIMEOUT_SECONDS,
                )
    return _pool_instance
