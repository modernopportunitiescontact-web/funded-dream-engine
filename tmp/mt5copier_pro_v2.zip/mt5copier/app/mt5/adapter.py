"""
app/mt5/adapter.py
------------------
Low-level wrapper around the MetaTrader5 Python package.

DESIGN RATIONALE FOR 30+ ACCOUNTS
===================================
The MetaTrader5 Python package has a critical constraint on Windows:
  - It can only hold ONE active terminal connection per process at a time.
  - mt5.initialize() / mt5.shutdown() switch the active session.
  - Concurrent calls from multiple threads WILL corrupt each other's context.

Our solution: a PER-ACCOUNT serialised worker approach.
  - Each Account gets its own AccountWorker that runs in a dedicated thread.
  - The worker owns a single persistent MT5 connection for its account.
  - All MT5 operations for that account are submitted as callables to the
    worker's queue and executed sequentially in its thread.
  - No two accounts ever share or race for the MT5 global state.

This means with 30+ accounts we have 30+ threads, each owning one MT5
session independently. On Windows this requires 30+ separate MT5 terminals
running simultaneously (one per account/broker). This is the realistic
production model for multi-account copying on Windows.

If a single terminal is being reused across accounts (same broker, different
logins), the worker handles re-initialization transparently.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger("mt5copier.adapter")

# Guard: gracefully handle import failure (e.g. running on Linux for tests)
try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
except ImportError:
    mt5 = None  # type: ignore[assignment]
    MT5_AVAILABLE = False
    logger.warning("MetaTrader5 package not available. Stub mode active.")


@dataclass
class PositionSnapshot:
    """Immutable snapshot of one open MT5 position."""
    ticket: int
    symbol: str
    volume: float
    type: int          # 0 = BUY, 1 = SELL
    price_open: float
    sl: float
    tp: float
    comment: str


@dataclass
class AccountSnapshot:
    """Immutable snapshot of MT5 account info."""
    login: int
    name: str
    server: str
    balance: float
    equity: float
    margin: float
    margin_free: float
    currency: str
    leverage: int


class MT5Adapter:
    """
    Thin stateless wrapper around MT5 API calls.
    Assumes the MT5 session is already initialised by the calling context.
    All methods raise RuntimeError on failure — callers must handle.
    """

    # ── Connection ────────────────────────────────────────────────────────────

    @staticmethod
    def initialize(
        login: int,
        password: str,
        server: str,
        terminal_path: Optional[str] = None,
    ) -> None:
        """Initialize (or re-initialize) the MT5 connection for one account."""
        if not MT5_AVAILABLE:
            raise RuntimeError("MetaTrader5 package is not installed.")

        kwargs: Dict[str, Any] = {
            "login": int(login),
            "password": password,
            "server": server,
        }
        if terminal_path:
            ok = mt5.initialize(path=terminal_path, **kwargs)
        else:
            ok = mt5.initialize(**kwargs)

        if not ok:
            code, desc = mt5.last_error()
            raise RuntimeError(f"MT5 initialize failed [{code}]: {desc}")

        info = mt5.account_info()
        if info is None:
            code, desc = mt5.last_error()
            mt5.shutdown()
            raise RuntimeError(f"MT5 account_info unavailable after init [{code}]: {desc}")

    @staticmethod
    def shutdown() -> None:
        if MT5_AVAILABLE:
            mt5.shutdown()

    # ── Account info ──────────────────────────────────────────────────────────

    @staticmethod
    def account_snapshot() -> AccountSnapshot:
        info = mt5.account_info()
        if info is None:
            code, desc = mt5.last_error()
            raise RuntimeError(f"MT5 account_info failed [{code}]: {desc}")
        return AccountSnapshot(
            login=int(info.login),
            name=str(info.name),
            server=str(info.server),
            balance=float(info.balance),
            equity=float(info.equity),
            margin=float(info.margin),
            margin_free=float(info.margin_free),
            currency=str(info.currency),
            leverage=int(info.leverage),
        )

    # ── Positions ─────────────────────────────────────────────────────────────

    @staticmethod
    def positions_all() -> List[PositionSnapshot]:
        raw = mt5.positions_get()
        if raw is None:
            code, desc = mt5.last_error()
            raise RuntimeError(f"MT5 positions_get failed [{code}]: {desc}")
        return [
            PositionSnapshot(
                ticket=int(p.ticket),
                symbol=str(p.symbol),
                volume=float(p.volume),
                type=int(p.type),
                price_open=float(p.price_open),
                sl=float(p.sl),
                tp=float(p.tp),
                comment=str(getattr(p, "comment", "")),
            )
            for p in raw
        ]

    @staticmethod
    def position_by_ticket(ticket: int) -> Optional[PositionSnapshot]:
        raw = mt5.positions_get(ticket=ticket)
        if not raw:
            return None
        p = raw[0]
        return PositionSnapshot(
            ticket=int(p.ticket),
            symbol=str(p.symbol),
            volume=float(p.volume),
            type=int(p.type),
            price_open=float(p.price_open),
            sl=float(p.sl),
            tp=float(p.tp),
            comment=str(getattr(p, "comment", "")),
        )

    # ── Symbol helpers ────────────────────────────────────────────────────────

    @staticmethod
    def ensure_symbol(symbol: str) -> None:
        info = mt5.symbol_info(symbol)
        if info is None:
            raise RuntimeError(f"Symbol not found on broker: {symbol}")
        if not info.visible:
            if not mt5.symbol_select(symbol, True):
                raise RuntimeError(f"Cannot select symbol in MarketWatch: {symbol}")

    @staticmethod
    def normalize_volume(symbol: str, volume: float) -> float:
        info = mt5.symbol_info(symbol)
        if info is None:
            raise RuntimeError(f"Symbol not found: {symbol}")

        step = float(info.volume_step)
        minimum = float(info.volume_min)
        maximum = float(info.volume_max)

        clamped = max(minimum, min(maximum, volume))
        steps = round(clamped / step)
        normalized = steps * step

        # Determine required decimal places from step
        step_str = f"{step:.10f}".rstrip("0")
        decimals = len(step_str.split(".")[1]) if "." in step_str else 0
        return round(normalized, decimals)

    @staticmethod
    def current_price(symbol: str, order_type: int) -> float:
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            raise RuntimeError(f"Cannot get market tick for: {symbol}")
        # ORDER_TYPE_BUY → we pay ask; ORDER_TYPE_SELL → we receive bid
        if order_type == mt5.ORDER_TYPE_BUY:
            return float(tick.ask)
        if order_type == mt5.ORDER_TYPE_SELL:
            return float(tick.bid)
        raise RuntimeError(f"Unknown order_type: {order_type}")

    # ── Order execution ───────────────────────────────────────────────────────

    @staticmethod
    def send_market_order(
        symbol: str,
        order_type: int,
        volume: float,
        sl: Optional[float],
        tp: Optional[float],
        comment: str,
        magic: int,
        deviation: int,
    ) -> int:
        """
        Open a market order. Returns the position ticket on success.
        Raises RuntimeError on any failure.
        """
        from app.core.config import get_settings
        settings = get_settings()

        MT5Adapter.ensure_symbol(symbol)
        final_volume = MT5Adapter.normalize_volume(symbol, volume)
        price = MT5Adapter.current_price(symbol, order_type)

        # Determine the correct filling mode for this symbol
        filling_mode = MT5Adapter._get_filling_mode(symbol)

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": final_volume,
            "type": order_type,
            "price": price,
            "sl": float(sl) if sl and sl > 0 else 0.0,
            "tp": float(tp) if tp and tp > 0 else 0.0,
            "deviation": deviation,
            "magic": magic,
            "comment": comment[:31],
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": filling_mode,
        }

        result = mt5.order_send(request)
        if result is None:
            code, desc = mt5.last_error()
            raise RuntimeError(f"order_send returned None [{code}]: {desc}")

        retcode = int(result.retcode)
        if retcode not in {mt5.TRADE_RETCODE_DONE, mt5.TRADE_RETCODE_PLACED}:
            raise RuntimeError(
                f"Order open failed retcode={retcode} "
                f"comment={getattr(result, 'comment', 'n/a')!r}"
            )

        ticket = int(getattr(result, "order", 0) or getattr(result, "deal", 0))
        if ticket <= 0:
            # Try to find the position by comment as a fallback
            raise RuntimeError(
                f"Order succeeded (retcode={retcode}) but no ticket in response. "
                "Check MT5 terminal manually."
            )
        return ticket

    @staticmethod
    def close_position(ticket: int, deviation: int, magic: int) -> None:
        """
        Close an open position by ticket.
        Silently returns if the position no longer exists.
        """
        pos = MT5Adapter.position_by_ticket(ticket)
        if pos is None:
            logger.info("close_position: ticket %d not found (already closed?)", ticket)
            return

        close_type = (
            mt5.ORDER_TYPE_SELL
            if pos.type == mt5.POSITION_TYPE_BUY
            else mt5.ORDER_TYPE_BUY
        )
        MT5Adapter.ensure_symbol(pos.symbol)
        filling_mode = MT5Adapter._get_filling_mode(pos.symbol)

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": pos.symbol,
            "position": int(pos.ticket),
            "volume": float(pos.volume),
            "type": close_type,
            "price": MT5Adapter.current_price(pos.symbol, close_type),
            "deviation": deviation,
            "magic": magic,
            "comment": "copier-close",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": filling_mode,
        }

        result = mt5.order_send(request)
        if result is None:
            code, desc = mt5.last_error()
            raise RuntimeError(f"Close order_send returned None [{code}]: {desc}")

        retcode = int(result.retcode)
        if retcode not in {mt5.TRADE_RETCODE_DONE, mt5.TRADE_RETCODE_PLACED}:
            raise RuntimeError(
                f"Close failed retcode={retcode} "
                f"comment={getattr(result, 'comment', 'n/a')!r}"
            )

    @staticmethod
    def modify_sl_tp(
        ticket: int,
        sl: Optional[float],
        tp: Optional[float],
    ) -> None:
        """Modify SL/TP on an open position. Silently skips if position gone."""
        pos = MT5Adapter.position_by_ticket(ticket)
        if pos is None:
            return

        request = {
            "action": mt5.TRADE_ACTION_SLTP,
            "position": int(pos.ticket),
            "symbol": pos.symbol,
            "sl": float(sl) if sl and sl > 0 else 0.0,
            "tp": float(tp) if tp and tp > 0 else 0.0,
        }

        result = mt5.order_send(request)
        if result is None:
            code, desc = mt5.last_error()
            raise RuntimeError(f"Modify SL/TP order_send returned None [{code}]: {desc}")

        retcode = int(result.retcode)
        if retcode not in {mt5.TRADE_RETCODE_DONE, mt5.TRADE_RETCODE_PLACED}:
            raise RuntimeError(
                f"Modify SL/TP failed retcode={retcode} "
                f"comment={getattr(result, 'comment', 'n/a')!r}"
            )

    # ── Internal helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _get_filling_mode(symbol: str) -> int:
        """
        Determine the correct order filling type for a symbol.
        Different brokers support different filling modes.
        Falls back to IOC if FOK is not available.
        """
        info = mt5.symbol_info(symbol)
        if info is None:
            return mt5.ORDER_FILLING_IOC

        filling_flags = getattr(info, "filling_mode", 0)
        # Bit 0 = FOK supported, Bit 1 = IOC supported
        if filling_flags & 1:
            return mt5.ORDER_FILLING_FOK
        if filling_flags & 2:
            return mt5.ORDER_FILLING_IOC
        return mt5.ORDER_FILLING_RETURN
