"""
app/mt5/types.py
----------------
Pure-data types for MT5 operations.
No dependency on the MetaTrader5 package here — these are
used throughout the application including in tests.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# MT5 position type constants (mirrors MT5 POSITION_TYPE_*)
POSITION_TYPE_BUY  = 0
POSITION_TYPE_SELL = 1

# MT5 order type constants (mirrors MT5 ORDER_TYPE_*)
ORDER_TYPE_BUY  = 0
ORDER_TYPE_SELL = 1


@dataclass(frozen=True)
class PositionSnapshot:
    """Immutable snapshot of one MT5 open position."""
    ticket:      int
    symbol:      str
    volume:      float
    type:        int          # POSITION_TYPE_BUY or POSITION_TYPE_SELL
    price_open:  float
    sl:          float        # 0.0 means no SL set
    tp:          float        # 0.0 means no TP set
    comment:     str


@dataclass(frozen=True)
class AccountSnapshot:
    """Minimal subset of MT5 account_info we care about."""
    login:    int
    name:     str
    server:   str
    balance:  float
    equity:   float
    currency: str


@dataclass
class OrderResult:
    """Result of a send_market_order call."""
    ticket:  int
    volume:  float
    symbol:  str
    retcode: int
