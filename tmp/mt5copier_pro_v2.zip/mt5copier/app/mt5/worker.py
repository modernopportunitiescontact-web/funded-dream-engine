"""
app/mt5/worker.py
-----------------
Per-account MT5 worker — GLOBAL lock, persistent session.

DEFINITIVE ARCHITECTURE
=======================
Problem summary from production logs:
1. [-10004] No IPC: terminal not running OR session stolen by another thread
2. [1] Success error: mt5.initialize() fails because another session is active
3. Workers not starting: bootstrap runs while MT5 is still initializing

Root cause: mt5.initialize() + mt5.shutdown() cycle per operation is BROKEN
when multiple threads call it. The DLL gets confused.

Solution:
- ONE global lock (_G) for ALL MT5 operations across ALL workers.
- Each worker calls initialize() → runs task → calls shutdown() while holding _G.
- initialize() is called EVERY time before a task (switches account context).
- shutdown() is called EVERY time after (releases DLL state cleanly).
- NO concurrent MT5 calls of any kind.
- Workers run in threads but MT5 calls are strictly serialised via _G.

This is the only safe model for the MT5 Python DLL on Windows.
"""
from __future__ import annotations

import logging
import queue
import threading
import time
from concurrent.futures import Future
from typing import Callable, Optional, TypeVar

logger = logging.getLogger("mt5copier.worker")
T = TypeVar("T")

# THE one and only global MT5 lock.
# Every mt5.* call in the entire process must hold this lock.
_G = threading.Lock()

_STOP = object()


def _safe_shutdown() -> None:
    try:
        import MetaTrader5 as mt5
        mt5.shutdown()
    except Exception:
        pass


def _do_init(login: int, password: str, server: str,
             terminal_path: Optional[str]) -> str:
    """
    Initialize MT5 for one account. Returns "" on success, error string on fail.
    Must be called while holding _G.
    """
    try:
        import MetaTrader5 as mt5
    except ImportError:
        return "MetaTrader5 package not installed"

    # Always shutdown first to clear any stale state
    try:
        mt5.shutdown()
    except Exception:
        pass

    kwargs = {"login": int(login), "password": password, "server": server}
    if terminal_path:
        ok = mt5.initialize(path=terminal_path, **kwargs)
    else:
        ok = mt5.initialize(**kwargs)

    if not ok:
        code, desc = mt5.last_error()
        # code=1 means already initialized — try using as-is
        if code == 1:
            info = mt5.account_info()
            if info is not None and int(info.login) == int(login):
                return ""  # already connected to correct account
        return f"MT5 initialize failed [{code}]: {desc}"

    # Verify correct account
    info = mt5.account_info()
    if info is None:
        code, desc = mt5.last_error()
        mt5.shutdown()
        return f"account_info failed [{code}]: {desc}"

    if int(info.login) != int(login):
        mt5.shutdown()
        return f"Wrong account: got {info.login}, expected {login}"

    return ""  # success


class AccountWorker:
    """
    Per-account worker thread. All MT5 operations serialised via global lock _G.
    """

    def __init__(
        self,
        account_id: int,
        login: int,
        password: str,
        server: str,
        terminal_path: Optional[str] = None,
        operation_timeout: float = 20.0,
    ) -> None:
        self.account_id     = account_id
        self._login         = login
        self._password      = password
        self._server        = server
        self._terminal_path = terminal_path
        self._op_timeout    = operation_timeout

        self._queue         : queue.Queue = queue.Queue()
        self._thread        : Optional[threading.Thread] = None
        self._stop_event    = threading.Event()

        self._connected     : bool = False
        self._last_error    : Optional[str] = None
        self._state_lock    = threading.Lock()

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name=f"mt5-worker-{self.account_id}",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        self._queue.put(_STOP)
        if self._thread:
            self._thread.join(timeout=12)
            self._thread = None

    def submit(self, fn: Callable[[], T]) -> "Future[T]":
        """Queue a callable. Returns Future resolved in worker thread."""
        f: Future[T] = Future()
        self._queue.put((fn, f))
        return f

    @property
    def is_connected(self) -> bool:
        with self._state_lock:
            return self._connected

    @property
    def last_error(self) -> Optional[str]:
        with self._state_lock:
            return self._last_error

    @property
    def is_alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ── Worker loop ───────────────────────────────────────────────────────────

    def _run(self) -> None:
        logger.info("Worker %d start login=%d server=%s",
                    self.account_id, self._login, self._server)

        # Initial connection test
        self._test_connection()

        while not self._stop_event.is_set():
            try:
                item = self._queue.get(timeout=120)
            except queue.Empty:
                self._test_connection()
                continue

            if item is _STOP:
                break

            fn, fut = item
            self._execute(fn, fut)

        logger.info("Worker %d stopped.", self.account_id)

    # ── Execute one task ──────────────────────────────────────────────────────

    def _execute(self, fn: Callable, fut: Future, retries: int = 2) -> None:
        """
        Acquire global lock → initialize for THIS account → run fn() → shutdown.
        Retries once on connection errors.
        """
        last_err: Optional[Exception] = None

        for attempt in range(1, retries + 1):
            with _G:
                # Initialize MT5 for this specific account
                err = _do_init(
                    self._login, self._password,
                    self._server, self._terminal_path
                )
                if err:
                    with self._state_lock:
                        self._connected  = False
                        self._last_error = err
                    _safe_shutdown()
                    last_err = RuntimeError(err)
                    if attempt < retries and _retryable(err):
                        time.sleep(0.3)
                        continue
                    fut.set_exception(last_err)
                    return

                with self._state_lock:
                    self._connected  = True
                    self._last_error = None

                try:
                    result = fn()
                    fut.set_result(result)
                    return  # ✅ success
                except Exception as exc:
                    last_err = exc
                    with self._state_lock:
                        self._last_error = str(exc)
                    if attempt < retries and _retryable(str(exc)):
                        _safe_shutdown()
                        time.sleep(0.3)
                        continue
                    fut.set_exception(exc)
                    return
                finally:
                    _safe_shutdown()

        if last_err:
            try:
                fut.set_exception(last_err)
            except Exception:
                pass

    # ── Connection test (non-blocking on global lock) ─────────────────────────

    def _test_connection(self) -> None:
        """
        Quick connection test. Uses non-blocking tryacquire so we never
        block if the engine is already using MT5. Skips account_snapshot
        to minimise lock hold time.
        """
        acquired = _G.acquire(blocking=False)
        if not acquired:
            return  # engine is busy — connection is probably fine
        try:
            err = _do_init(
                self._login, self._password,
                self._server, self._terminal_path
            )
            if err:
                with self._state_lock:
                    self._connected  = False
                    self._last_error = err
                logger.warning("Worker %d test failed: %s",
                               self.account_id, err)
            else:
                with self._state_lock:
                    self._connected  = True
                    self._last_error = None
                # Don't call account_snapshot here — reduces lock hold time
                logger.debug("Worker %d test OK", self.account_id)
        finally:
            _safe_shutdown()
            _G.release()


# ── Helpers ───────────────────────────────────────────────────────────────────

_RETRY_KEYWORDS = (
    "ipc timeout", "-10005", "-10004", "no ipc connection",
    "ipc", "authorization failed", "-6", "success",
)

def _retryable(msg: str) -> bool:
    m = msg.lower()
    return any(k in m for k in _RETRY_KEYWORDS)
