"""
app/schemas/account.py
----------------------
Pydantic v2 request/response schemas for the Account resource.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


# ── Request schemas ───────────────────────────────────────────────────────────

class AccountCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120, description="Unique friendly name")
    login: int = Field(description="MT5 account number")
    password: str = Field(min_length=1, description="MT5 account password (stored encrypted)")
    server: str = Field(min_length=1, max_length=255, description="MT5 broker server name")
    terminal_path: Optional[str] = Field(
        default=None,
        description="Full path to terminal64.exe (optional)",
    )
    role_hint: str = Field(
        default="both",
        pattern="^(master|slave|both)$",
        description="Role hint for the UI filter",
    )
    is_enabled: bool = Field(default=True)


class AccountUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    password: Optional[str] = Field(default=None, min_length=1)
    server: Optional[str] = Field(default=None, min_length=1, max_length=255)
    terminal_path: Optional[str] = None
    role_hint: Optional[str] = Field(default=None, pattern="^(master|slave|both)$")
    is_enabled: Optional[bool] = None


# ── Response schemas ──────────────────────────────────────────────────────────

class AccountOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    login: int
    server: str
    terminal_path: Optional[str]
    role_hint: str
    is_enabled: bool
    last_status: str
    last_seen_at: Optional[datetime]
    created_at: datetime


class AccountTestResult(BaseModel):
    ok: bool
    login: Optional[int] = None
    name: Optional[str] = None
    server: Optional[str] = None
    balance: Optional[float] = None
    equity: Optional[float] = None
    currency: Optional[str] = None
    error: Optional[str] = None


class AccountToggleResponse(BaseModel):
    id: int
    is_enabled: bool
