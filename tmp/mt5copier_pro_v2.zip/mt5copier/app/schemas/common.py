"""
app/schemas/mirror.py + log.py combined
----------------------------------------
Pydantic v2 response schemas for PositionMirror and EventLog.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict


class PositionMirrorOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    link_id: int
    master_ticket: int
    slave_ticket: int
    symbol_master: str
    symbol_slave: str
    volume_master: float
    volume_slave: float
    side_master: int
    is_open: bool
    opened_at: datetime
    closed_at: Optional[datetime]
    last_error: Optional[str]


class EventLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    level: str
    message: str
    context: Dict[str, Any] = {}
    created_at: datetime


class StatusResponse(BaseModel):
    accounts_total: int
    accounts_enabled: int
    links_total: int
    links_active: int
    open_mirrors: int
    engine_running: bool
    recent_logs: List[EventLogOut]


class HealthResponse(BaseModel):
    ok: bool
    name: str
    version: str
    db_ok: bool
    engine_running: bool
