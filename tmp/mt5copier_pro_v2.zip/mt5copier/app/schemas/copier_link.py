"""
app/schemas/copier_link.py
--------------------------
Pydantic v2 request/response schemas for the CopierLink resource.
"""
from __future__ import annotations

from datetime import datetime
from typing import Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


# ── Request schemas ───────────────────────────────────────────────────────────

class CopierLinkCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    master_account_id: int
    slave_account_id: int
    lot_multiplier: float = Field(default=1.0, gt=0, description="Volume multiplier (e.g. 0.5 = half size)")
    fixed_lot: Optional[float] = Field(
        default=None, gt=0, description="If set, overrides lot_multiplier with a fixed volume"
    )
    symbol_map: Dict[str, str] = Field(
        default_factory=dict,
        description='Map master symbol to slave symbol e.g. {"EURUSD": "EURUSDs"}',
    )
    copy_sl: bool = True
    copy_tp: bool = True
    reverse_side: bool = False
    comment_prefix: str = Field(default="copier", max_length=40)
    is_active: bool = True


class CopierLinkUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    lot_multiplier: Optional[float] = Field(default=None, gt=0)
    fixed_lot: Optional[float] = Field(default=None, gt=0)
    symbol_map: Optional[Dict[str, str]] = None
    copy_sl: Optional[bool] = None
    copy_tp: Optional[bool] = None
    reverse_side: Optional[bool] = None
    comment_prefix: Optional[str] = Field(default=None, max_length=40)


# ── Response schemas ──────────────────────────────────────────────────────────

class CopierLinkOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    master_account_id: int
    slave_account_id: int
    lot_multiplier: float
    fixed_lot: Optional[float]
    symbol_map: Dict[str, str]
    copy_sl: bool
    copy_tp: bool
    reverse_side: bool
    comment_prefix: str
    is_active: bool
    last_run_at: Optional[datetime]
    last_error: Optional[str]
    retry_count: int
    next_retry_at: Optional[datetime]
    created_at: datetime


class ToggleResponse(BaseModel):
    id: int
    is_active: bool
