"""
app/main.py
-----------
FastAPI application factory.
Wires together: DB init, worker pool bootstrap, copier engine, routes, middleware.
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.core.config import get_settings
from app.core.logging import configure_logging, log_event
from app.core.state import get_app_state
from app.core.websocket_hub import WebSocketHub

configure_logging()
logger = logging.getLogger("mt5copier")
settings = get_settings()


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup → yield → Shutdown."""

    # 1. Initialise database tables
    from app.db.base import Base
    from app.db.session import engine
    import app.db  # ensures all models are registered  # noqa: F401

    Base.metadata.create_all(bind=engine)
    logger.info("Database tables ensured.")

    # 2. Store event loop + ws hub in global state
    state = get_app_state()
    state.main_loop = asyncio.get_running_loop()
    state.ws_hub = WebSocketHub()

    # 3. Bootstrap MT5 worker pool (starts one thread per enabled account)
    from app.mt5.pool import get_worker_pool
    pool = get_worker_pool()
    pool.bootstrap_from_db()

    # 4. Start copier engine
    from app.copier.engine import get_copier_engine
    engine_obj = get_copier_engine()
    engine_obj.start()

    log_event("INFO", f"{settings.APP_NAME} v{settings.APP_VERSION} started")
    logger.info("%s v%s ready.", settings.APP_NAME, settings.APP_VERSION)

    yield

    # ── Shutdown ──────────────────────────────────────────────────────────────
    logger.info("Shutting down...")
    engine_obj.stop()
    pool.stop_all()
    log_event("INFO", f"{settings.APP_NAME} stopped gracefully")


# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        docs_url="/api/docs" if settings.DEBUG else None,
        redoc_url=None,
        lifespan=lifespan,
    )

    # ── CORS ──────────────────────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── API routes ────────────────────────────────────────────────────────────
    from app.api.routes.auth import router as auth_router
    from app.api.routes.accounts import router as accounts_router
    from app.api.routes.links import router as links_router
    from app.api.routes.monitoring import router as monitoring_router
    from app.api.routes.ws import router as ws_router

    app.include_router(auth_router, prefix="/api")
    app.include_router(accounts_router, prefix="/api")
    app.include_router(links_router, prefix="/api")
    app.include_router(monitoring_router, prefix="/api")
    app.include_router(ws_router)

    # ── Static files ──────────────────────────────────────────────────────────
    import os
    static_dir = os.path.join(os.path.dirname(__file__), "..", "frontend", "static")
    if os.path.isdir(static_dir):
        app.mount("/static", StaticFiles(directory=static_dir), name="static")

    # ── Dashboard SPA (catch-all) ─────────────────────────────────────────────
    @app.get("/", response_class=HTMLResponse)
    @app.get("/accounts", response_class=HTMLResponse)
    @app.get("/links", response_class=HTMLResponse)
    @app.get("/mirrors", response_class=HTMLResponse)
    @app.get("/logs", response_class=HTMLResponse)
    async def dashboard() -> HTMLResponse:
        from app.frontend.renderer import render_dashboard
        return HTMLResponse(content=render_dashboard())

    # ── Global exception handler ──────────────────────────────────────────────
    @app.exception_handler(Exception)
    async def unhandled_exception(request: Request, exc: Exception) -> JSONResponse:
        logger.error("Unhandled exception on %s: %s", request.url.path, exc, exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error", "error": str(exc)},
        )

    return app


app = create_app()
