"""
app/frontend/renderer.py
------------------------
Returns the complete single-page dashboard HTML.
Kept in Python so we have zero template-engine dependency
while keeping the HTML cleanly separated from route logic.
"""
from __future__ import annotations

from app.core.config import get_settings

settings = get_settings()


def render_dashboard() -> str:
    return _DASHBOARD_HTML.replace("__APP_NAME__", settings.APP_NAME).replace(
        "__APP_VERSION__", settings.APP_VERSION
    )


# ─────────────────────────────────────────────────────────────────────────────
# Full dashboard HTML — dark professional trading operations UI
# ─────────────────────────────────────────────────────────────────────────────
_DASHBOARD_HTML = r"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>__APP_NAME__</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
  <style>
    :root{
      --bg:#080d14;--surface:#0e1520;--card:#111c2d;--card2:#162236;
      --border:#1e2f47;--border2:#243754;
      --text:#dce9ff;--text2:#7d9abf;--text3:#4a6585;
      --accent:#3b82f6;--accent2:#1d4ed8;--accent-glow:rgba(59,130,246,.18);
      --green:#10b981;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;
      --green-bg:rgba(16,185,129,.10);--red-bg:rgba(239,68,68,.10);
      --yellow-bg:rgba(245,158,11,.10);
      --font-sans:'IBM Plex Sans',sans-serif;
      --font-mono:'IBM Plex Mono',monospace;
      --r:10px;--r2:14px;
    }
    *{box-sizing:border-box;margin:0;padding:0;}
    html,body{height:100%;background:var(--bg);color:var(--text);font-family:var(--font-sans);font-size:14px;line-height:1.55;}
    a{color:var(--accent);text-decoration:none;}
    /* ── Layout ── */
    .app{display:flex;height:100vh;overflow:hidden;}
    .sidebar{width:220px;min-width:220px;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;padding:0;}
    .sidebar-logo{padding:20px 18px 16px;border-bottom:1px solid var(--border);}
    .sidebar-logo .name{font-weight:700;font-size:15px;letter-spacing:.02em;color:var(--text);}
    .sidebar-logo .ver{font-size:11px;color:var(--text3);font-family:var(--font-mono);}
    .sidebar-logo .dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--green);margin-right:6px;box-shadow:0 0 6px var(--green);}
    .nav{flex:1;padding:10px 0;}
    .nav-item{display:flex;align-items:center;gap:10px;padding:10px 18px;cursor:pointer;color:var(--text2);border-left:3px solid transparent;transition:all .15s;}
    .nav-item:hover{color:var(--text);background:rgba(59,130,246,.06);}
    .nav-item.active{color:var(--accent);background:var(--accent-glow);border-left-color:var(--accent);}
    .nav-item svg{flex-shrink:0;opacity:.8;}
    .nav-item.active svg{opacity:1;}
    .sidebar-footer{padding:14px 18px;border-top:1px solid var(--border);}
    .engine-pill{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--text3);}
    .engine-pill .dot{width:7px;height:7px;border-radius:50%;background:var(--text3);}
    .engine-pill.running .dot{background:var(--green);box-shadow:0 0 5px var(--green);}
    .engine-pill .label{color:var(--text2);}
    /* ── Main ── */
    .main{flex:1;display:flex;flex-direction:column;overflow:hidden;}
    .topbar{height:52px;min-height:52px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 24px;background:var(--surface);}
    .topbar-title{font-size:15px;font-weight:600;color:var(--text);}
    .topbar-right{display:flex;align-items:center;gap:10px;}
    .content{flex:1;overflow-y:auto;padding:24px;}
    /* ── Cards ── */
    .stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:14px;margin-bottom:24px;}
    .stat-card{background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:18px;position:relative;overflow:hidden;}
    .stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;}
    .stat-card.blue::before{background:linear-gradient(90deg,var(--accent),#60a5fa);}
    .stat-card.green::before{background:linear-gradient(90deg,var(--green),#34d399);}
    .stat-card.red::before{background:linear-gradient(90deg,var(--red),#f87171);}
    .stat-card.purple::before{background:linear-gradient(90deg,var(--purple),#a78bfa);}
    .stat-card.yellow::before{background:linear-gradient(90deg,var(--yellow),#fcd34d);}
    .stat-label{font-size:11px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--text3);margin-bottom:10px;}
    .stat-value{font-size:28px;font-weight:700;color:var(--text);font-family:var(--font-mono);}
    .stat-sub{font-size:11px;color:var(--text3);margin-top:4px;}
    /* ── Section ── */
    .section{background:var(--card);border:1px solid var(--border);border-radius:var(--r2);margin-bottom:20px;}
    .section-header{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--border);}
    .section-title{font-size:13px;font-weight:600;color:var(--text);letter-spacing:.02em;}
    .section-body{padding:18px;}
    /* ── Tables ── */
    .tbl-wrap{overflow-x:auto;}
    table{width:100%;border-collapse:collapse;font-size:13px;}
    th{padding:8px 12px;text-align:left;font-size:11px;font-weight:600;letter-spacing:.05em;text-transform:uppercase;color:var(--text3);border-bottom:1px solid var(--border);white-space:nowrap;}
    td{padding:10px 12px;border-bottom:1px solid var(--border);vertical-align:middle;color:var(--text2);}
    tr:last-child td{border-bottom:none;}
    tr:hover td{background:rgba(59,130,246,.04);}
    .td-name{color:var(--text);font-weight:500;}
    .td-mono{font-family:var(--font-mono);font-size:12px;}
    /* ── Pills ── */
    .pill{display:inline-flex;align-items:center;gap:5px;padding:3px 9px;border-radius:999px;font-size:11px;font-weight:600;white-space:nowrap;border:1px solid transparent;}
    .pill .dot{width:5px;height:5px;border-radius:50%;}
    .pill.enabled,.pill.active{background:var(--green-bg);color:var(--green);border-color:rgba(16,185,129,.2);}
    .pill.enabled .dot,.pill.active .dot{background:var(--green);}
    .pill.disabled,.pill.paused{background:var(--red-bg);color:var(--red);border-color:rgba(239,68,68,.2);}
    .pill.disabled .dot,.pill.paused .dot{background:var(--red);}
    .pill.master{background:rgba(139,92,246,.1);color:#a78bfa;border-color:rgba(139,92,246,.2);}
    .pill.slave{background:rgba(245,158,11,.1);color:#fcd34d;border-color:rgba(245,158,11,.2);}
    .pill.both{background:rgba(59,130,246,.1);color:#93c5fd;border-color:rgba(59,130,246,.2);}
    .pill.error{background:var(--red-bg);color:var(--red);border-color:rgba(239,68,68,.2);}
    /* ── Log levels ── */
    .log-INFO{color:#60a5fa;}
    .log-WARNING{color:var(--yellow);}
    .log-ERROR{color:var(--red);}
    .log-DEBUG{color:var(--text3);}
    /* ── Buttons ── */
    .btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:var(--r);border:1px solid transparent;font-size:12px;font-weight:600;cursor:pointer;transition:all .15s;white-space:nowrap;font-family:var(--font-sans);}
    .btn-primary{background:var(--accent);color:#fff;border-color:var(--accent2);}
    .btn-primary:hover{background:#2563eb;}
    .btn-secondary{background:var(--card2);color:var(--text2);border-color:var(--border2);}
    .btn-secondary:hover{color:var(--text);border-color:var(--accent);}
    .btn-danger{background:rgba(239,68,68,.12);color:var(--red);border-color:rgba(239,68,68,.2);}
    .btn-danger:hover{background:rgba(239,68,68,.22);}
    .btn-warn{background:rgba(245,158,11,.12);color:var(--yellow);border-color:rgba(245,158,11,.2);}
    .btn-warn:hover{background:rgba(245,158,11,.22);}
    .btn-sm{padding:5px 10px;font-size:11px;}
    .btn-icon{padding:6px;border-radius:8px;}
    /* ── Forms ── */
    .form-grid{display:grid;gap:14px;}
    .form-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;}
    .form-group{display:flex;flex-direction:column;gap:5px;}
    label.form-label{font-size:11px;font-weight:600;letter-spacing:.05em;text-transform:uppercase;color:var(--text3);}
    input.form-control,select.form-control,textarea.form-control{
      background:var(--bg);border:1px solid var(--border2);border-radius:var(--r);
      color:var(--text);padding:9px 12px;font-size:13px;font-family:var(--font-sans);
      width:100%;transition:border-color .15s;outline:none;
    }
    input.form-control:focus,select.form-control:focus,textarea.form-control:focus{
      border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-glow);
    }
    textarea.form-control{min-height:70px;resize:vertical;}
    .form-check{display:flex;align-items:center;gap:8px;cursor:pointer;}
    .form-check input{width:15px;height:15px;accent-color:var(--accent);}
    .form-check span{font-size:13px;color:var(--text2);}
    .form-actions{display:flex;gap:8px;align-items:center;padding-top:4px;}
    .form-hint{font-size:11px;color:var(--text3);margin-top:2px;}
    .form-error{font-size:11px;color:var(--red);margin-top:2px;}
    /* ── Toasts ── */
    #toast-container{position:fixed;top:18px;right:18px;z-index:9999;display:flex;flex-direction:column;gap:8px;max-width:360px;pointer-events:none;}
    .toast{padding:12px 16px;border-radius:var(--r2);font-size:13px;font-weight:500;border:1px solid var(--border);backdrop-filter:blur(8px);animation:slideIn .2s ease;pointer-events:all;}
    .toast.success{background:rgba(16,185,129,.15);color:#a7f3d0;border-color:rgba(16,185,129,.3);}
    .toast.error{background:rgba(239,68,68,.15);color:#fca5a5;border-color:rgba(239,68,68,.3);}
    .toast.info{background:rgba(59,130,246,.15);color:#bfdbfe;border-color:rgba(59,130,246,.3);}
    .toast.warning{background:rgba(245,158,11,.15);color:#fde68a;border-color:rgba(245,158,11,.3);}
    @keyframes slideIn{from{transform:translateX(20px);opacity:0;}to{transform:translateX(0);opacity:1;}}
    /* ── Logs pane ── */
    .log-stream{background:var(--bg);border:1px solid var(--border);border-radius:var(--r);padding:12px;height:340px;overflow-y:auto;font-family:var(--font-mono);font-size:12px;line-height:1.7;}
    .log-line{display:flex;gap:10px;}
    .log-time{color:var(--text3);flex-shrink:0;}
    .log-msg{word-break:break-word;}
    /* ── Modal ── */
    .modal-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:1000;align-items:center;justify-content:center;}
    .modal-backdrop.open{display:flex;}
    .modal{background:var(--card);border:1px solid var(--border2);border-radius:var(--r2);padding:24px;width:100%;max-width:520px;max-height:90vh;overflow-y:auto;box-shadow:0 24px 64px rgba(0,0,0,.5);}
    .modal-title{font-size:15px;font-weight:700;color:var(--text);margin-bottom:18px;}
    /* ── Login screen ── */
    .login-wrap{display:flex;align-items:center;justify-content:center;min-height:100vh;background:var(--bg);}
    .login-card{background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:36px;width:360px;box-shadow:0 24px 64px rgba(0,0,0,.4);}
    .login-title{font-size:20px;font-weight:700;color:var(--text);margin-bottom:4px;}
    .login-sub{font-size:13px;color:var(--text3);margin-bottom:24px;}
    /* ── Worker status ── */
    .worker-dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--text3);}
    .worker-dot.ok{background:var(--green);box-shadow:0 0 5px var(--green);}
    .worker-dot.err{background:var(--red);}
    /* ── Misc ── */
    .empty-state{padding:40px;text-align:center;color:var(--text3);font-size:13px;}
    .loading{color:var(--text3);font-size:13px;padding:16px;}
    .text-red{color:var(--red);}
    .text-green{color:var(--green);}
    .text-yellow{color:var(--yellow);}
    .text-muted{color:var(--text3);}
    .actions-cell{display:flex;gap:6px;flex-wrap:wrap;}
    ::-webkit-scrollbar{width:6px;height:6px;}
    ::-webkit-scrollbar-track{background:transparent;}
    ::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}
  </style>
</head>
<body>

<!-- ── Login screen ───────────────────────────────────────────────── -->
<div id="login-screen" class="login-wrap" style="display:none;">
  <div class="login-card">
    <div class="login-title">__APP_NAME__</div>
    <div class="login-sub">Sign in to your trading dashboard</div>
    <div class="form-group" style="margin-bottom:12px;">
      <label class="form-label">Username</label>
      <input id="l-user" class="form-control" type="text" autocomplete="username" value="admin"/>
    </div>
    <div class="form-group" style="margin-bottom:20px;">
      <label class="form-label">Password</label>
      <input id="l-pass" class="form-control" type="password" autocomplete="current-password"/>
    </div>
    <button class="btn btn-primary" style="width:100%;justify-content:center;" onclick="doLogin()">Sign In</button>
    <div id="l-err" class="form-error" style="margin-top:10px;min-height:16px;"></div>
  </div>
</div>

<!-- ── Main app ───────────────────────────────────────────────────── -->
<div id="app-shell" class="app" style="display:none;">
  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="name"><span class="dot"></span>__APP_NAME__</div>
      <div class="ver">v__APP_VERSION__</div>
    </div>
    <nav class="nav">
      <div class="nav-item active" data-page="overview" onclick="navigate('overview',this)">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
        Overview
      </div>
      <div class="nav-item" data-page="accounts" onclick="navigate('accounts',this)">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>
        Accounts
      </div>
      <div class="nav-item" data-page="links" onclick="navigate('links',this)">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
        Copier Links
      </div>
      <div class="nav-item" data-page="mirrors" onclick="navigate('mirrors',this)">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
        Mirrors
      </div>
      <div class="nav-item" data-page="logs" onclick="navigate('logs',this)">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
        Event Logs
      </div>
      <div class="nav-item" data-page="workers" onclick="navigate('workers',this)">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>
        Workers
      </div>
    </nav>
    <div class="sidebar-footer">
      <div class="engine-pill" id="engine-status-pill">
        <div class="dot"></div>
        <span class="label">Engine</span>
        <span id="engine-state-text">...</span>
      </div>
      <div style="margin-top:10px;">
        <button class="btn btn-secondary btn-sm" style="width:100%;justify-content:center;" onclick="doLogout()">Sign Out</button>
      </div>
    </div>
  </aside>

  <!-- Main -->
  <main class="main">
    <header class="topbar">
      <span class="topbar-title" id="page-title">Overview</span>
      <div class="topbar-right">
        <button class="btn btn-secondary btn-sm" onclick="refreshCurrentPage()">
          <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
          Refresh
        </button>
        <span id="ws-indicator" title="Live stream" style="font-size:11px;color:var(--text3);">⬤ offline</span>
      </div>
    </header>
    <div class="content" id="page-content">
      <div class="loading">Loading...</div>
    </div>
  </main>
</div>

<!-- ── Add Account Modal ──────────────────────────────────────────── -->
<div class="modal-backdrop" id="modal-account">
  <div class="modal">
    <div class="modal-title" id="modal-account-title">Add Account</div>
    <div class="form-grid">
      <input type="hidden" id="edit-account-id"/>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Name *</label>
          <input id="a-name" class="form-control" placeholder="BrokerA Master"/>
        </div>
        <div class="form-group">
          <label class="form-label">Role</label>
          <select id="a-role" class="form-control">
            <option value="both">both</option>
            <option value="master">master</option>
            <option value="slave">slave</option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Login (account number) *</label>
          <input id="a-login" class="form-control" type="number" placeholder="12345678"/>
        </div>
        <div class="form-group">
          <label class="form-label">Server *</label>
          <input id="a-server" class="form-control" placeholder="Broker-Live"/>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Password *</label>
        <input id="a-password" class="form-control" type="password" placeholder="Leave blank to keep unchanged (when editing)"/>
      </div>
      <div class="form-group">
        <label class="form-label">Terminal Path</label>
        <input id="a-terminal" class="form-control" placeholder="C:\Program Files\Broker MT5\terminal64.exe"/>
        <span class="form-hint">Optional. Required if multiple MT5 terminals are installed.</span>
      </div>
      <label class="form-check">
        <input id="a-enabled" type="checkbox" checked/>
        <span>Enabled</span>
      </label>
    </div>
    <div class="form-actions" style="margin-top:18px;">
      <button class="btn btn-primary" onclick="submitAccountForm()">Save Account</button>
      <button class="btn btn-secondary" onclick="closeModal('modal-account')">Cancel</button>
      <span id="a-err" class="form-error" style="flex:1;"></span>
    </div>
  </div>
</div>

<!-- ── Add Link Modal ─────────────────────────────────────────────── -->
<div class="modal-backdrop" id="modal-link">
  <div class="modal">
    <div class="modal-title" id="modal-link-title">Add Copier Link</div>
    <div class="form-grid">
      <input type="hidden" id="edit-link-id"/>
      <div class="form-group">
        <label class="form-label">Link Name *</label>
        <input id="lk-name" class="form-control" placeholder="Master1 → Slave1"/>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Master Account *</label>
          <select id="lk-master" class="form-control"></select>
        </div>
        <div class="form-group">
          <label class="form-label">Slave Account *</label>
          <select id="lk-slave" class="form-control"></select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Lot Multiplier</label>
          <input id="lk-multiplier" class="form-control" type="number" step="0.01" value="1.0" min="0.01"/>
        </div>
        <div class="form-group">
          <label class="form-label">Fixed Lot (overrides multiplier)</label>
          <input id="lk-fixedlot" class="form-control" type="number" step="0.01" min="0.01" placeholder="leave empty"/>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Symbol Map (JSON)</label>
        <textarea id="lk-symbolmap" class="form-control">{}</textarea>
        <span class="form-hint">e.g. {"EURUSD": "EURUSDs", "GOLD": "XAUUSD"}</span>
      </div>
      <div class="form-group">
        <label class="form-label">Comment Prefix</label>
        <input id="lk-prefix" class="form-control" value="copier" maxlength="40"/>
      </div>
      <div class="form-row" style="gap:20px;">
        <label class="form-check"><input id="lk-copysl" type="checkbox" checked/><span>Copy SL</span></label>
        <label class="form-check"><input id="lk-copytp" type="checkbox" checked/><span>Copy TP</span></label>
        <label class="form-check"><input id="lk-reverse" type="checkbox"/><span>Reverse Side</span></label>
        <label class="form-check"><input id="lk-active" type="checkbox" checked/><span>Active</span></label>
      </div>
    </div>
    <div class="form-actions" style="margin-top:18px;">
      <button class="btn btn-primary" onclick="submitLinkForm()">Save Link</button>
      <button class="btn btn-secondary" onclick="closeModal('modal-link')">Cancel</button>
      <span id="lk-err" class="form-error" style="flex:1;"></span>
    </div>
  </div>
</div>

<!-- ── Toast container ──────────────────────────────────────────────── -->
<div id="toast-container"></div>

<script>
'use strict';
// ── State ────────────────────────────────────────────────────────────────────
let _token = null;
let _currentPage = 'overview';
let _ws = null;
let _wsReconnectTimer = null;
let _accounts = [];
let _links = [];

// ── Helpers ──────────────────────────────────────────────────────────────────
function esc(v) {
  return String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
function fmt(dt) {
  if (!dt) return '—';
  try { return new Date(dt).toLocaleString(); } catch { return dt; }
}
function fmtRelative(dt) {
  if (!dt) return '—';
  const diff = Date.now() - new Date(dt).getTime();
  if (diff < 60000) return Math.round(diff/1000)+'s ago';
  if (diff < 3600000) return Math.round(diff/60000)+'m ago';
  return fmt(dt);
}

// ── API ───────────────────────────────────────────────────────────────────────
async function api(path, opts = {}, timeoutMs = 8000) {
  const headers = {'Content-Type':'application/json'};
  if (_token) headers['Authorization'] = 'Bearer ' + _token;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let res;
  try {
    res = await fetch('/api' + path, {
      headers,
      credentials: 'include',
      signal: controller.signal,
      ...opts
    });
  } catch(e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new Error('Request timeout — server busy');
    throw new Error('Network error — server unreachable');
  } finally {
    clearTimeout(timer);
  }

  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch {}
  if (!res.ok) {
    if (res.status === 401) { showLogin(); return null; }
    const msg = (data && data.detail)
      ? (typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail))
      : (text || 'Request failed');
    throw new Error(msg);
  }
  return data;
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function toast(msg, type='info') {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.textContent = msg;
  c.appendChild(t);
  setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(()=>t.remove(),300); }, 3500);
}

// ── Auth ──────────────────────────────────────────────────────────────────────
function showLogin() {
  _token = null;
  document.getElementById('login-screen').style.display='flex';
  document.getElementById('app-shell').style.display='none';
}
function showApp() {
  document.getElementById('login-screen').style.display='none';
  document.getElementById('app-shell').style.display='flex';
}
async function doLogin() {
  const user = document.getElementById('l-user').value.trim();
  const pass = document.getElementById('l-pass').value;
  document.getElementById('l-err').textContent='';
  try {
    const res = await fetch('/api/auth/login', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({username:user, password:pass})
    });
    const data = await res.json();
    if (!res.ok) { document.getElementById('l-err').textContent = data.detail || 'Login failed'; return; }
    _token = data.access_token;
    showApp();
    navigate('overview', document.querySelector('[data-page="overview"]'));
    connectWs();
  } catch(e) {
    document.getElementById('l-err').textContent = e.message;
  }
}
document.addEventListener('keydown', e => {
  if (e.key==='Enter' && document.getElementById('login-screen').style.display==='flex') doLogin();
});
async function doLogout() {
  await fetch('/api/auth/logout', {method:'POST'});
  _token=null;
  if(_ws) _ws.close();
  showLogin();
}

// ── Navigation ────────────────────────────────────────────────────────────────
const PAGE_TITLES = {overview:'Overview',accounts:'Accounts',links:'Copier Links',mirrors:'Mirrors',logs:'Event Logs',workers:'MT5 Workers'};
function navigate(page, el) {
  _currentPage = page;
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  if (el) el.classList.add('active');
  document.getElementById('page-title').textContent = PAGE_TITLES[page] || page;
  renderPage(page);
}
function refreshCurrentPage() {
  renderPage(_currentPage);
}
async function renderPage(page) {
  const c = document.getElementById('page-content');
  // Show spinner briefly but always clear it
  const loadTimer = setTimeout(() => {
    if (c.innerHTML.includes('Loading...')) {
      c.innerHTML = '<div class="empty-state text-red">⚠ Request timeout — check server connection.<br><button class="btn btn-secondary" style="margin-top:12px" onclick="refreshCurrentPage()">Retry</button></div>';
    }
  }, 8000);
  c.innerHTML = '<div class="loading">Loading...</div>';
  try {
    if (page==='overview') await renderOverview();
    else if (page==='accounts') await renderAccounts();
    else if (page==='links') await renderLinks();
    else if (page==='mirrors') await renderMirrors();
    else if (page==='logs') await renderLogs();
    else if (page==='workers') await renderWorkers();
  } catch(e) {
    toast(e.message, 'error');
    c.innerHTML = `<div class="empty-state text-red">⚠ ${esc(e.message)}<br><button class="btn btn-secondary" style="margin-top:12px" onclick="refreshCurrentPage()">Retry</button></div>`;
  } finally {
    clearTimeout(loadTimer);
  }
}

// ── Overview ──────────────────────────────────────────────────────────────────
async function renderOverview() {
  const s = await api('/status');
  if (s === null) { document.getElementById('page-content').innerHTML = '<div class="empty-state">Session expired — please refresh.</div>'; return; }
  updateEnginePill(s.engine_running);
  const c = document.getElementById('page-content');
  c.innerHTML = `
    <div class="stat-grid">
      <div class="stat-card blue">
        <div class="stat-label">Total Accounts</div>
        <div class="stat-value">${s.accounts_total}</div>
        <div class="stat-sub">${s.accounts_enabled} enabled</div>
      </div>
      <div class="stat-card green">
        <div class="stat-label">Active Links</div>
        <div class="stat-value">${s.links_active}</div>
        <div class="stat-sub">${s.links_total} total</div>
      </div>
      <div class="stat-card purple">
        <div class="stat-label">Open Mirrors</div>
        <div class="stat-value">${s.open_mirrors}</div>
        <div class="stat-sub">live positions</div>
      </div>
      <div class="stat-card ${s.engine_running ? 'green':'red'}">
        <div class="stat-label">Engine</div>
        <div class="stat-value" style="font-size:18px;">${s.engine_running ? 'RUNNING' : 'STOPPED'}</div>
        <div class="stat-sub">background copier</div>
      </div>
    </div>
    <div class="section">
      <div class="section-header">
        <span class="section-title">Recent Events</span>
        <button class="btn btn-secondary btn-sm" onclick="navigate('logs',document.querySelector('[data-page=logs]'))">View All</button>
      </div>
      <div class="section-body" style="padding:0;">
        <div class="log-stream" id="overview-log-stream">
          ${(s.recent_logs||[]).slice(-60).map(l => logLine(l)).join('')}
        </div>
      </div>
    </div>`;
  const ls = document.getElementById('overview-log-stream');
  if (ls) ls.scrollTop = ls.scrollHeight;
}

// ── Accounts ──────────────────────────────────────────────────────────────────
async function renderAccounts() {
  const _acc = await api('/accounts'); if(_acc===null) return; _accounts = _acc;
  const c = document.getElementById('page-content');
  const rows = _accounts.length === 0
    ? '<tr><td colspan="9"><div class="empty-state">No accounts yet. Add one to get started.</div></td></tr>'
    : _accounts.map(a => `
      <tr>
        <td class="td-mono">#${a.id}</td>
        <td class="td-name">${esc(a.name)}</td>
        <td class="td-mono">${a.login}</td>
        <td>${esc(a.server)}</td>
        <td><span class="pill ${a.role_hint}">${a.role_hint}</span></td>
        <td><span class="pill ${a.is_enabled?'enabled':'disabled'}"><span class="dot"></span>${a.is_enabled?'Enabled':'Disabled'}</span></td>
        <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${esc(a.last_status)}">${esc(a.last_status)}</td>
        <td class="text-muted" style="white-space:nowrap;">${fmtRelative(a.last_seen_at)}</td>
        <td>
          <div class="actions-cell">
            <button class="btn btn-secondary btn-sm" onclick="testAccount(${a.id})">Test</button>
            <button class="btn btn-secondary btn-sm" onclick="openEditAccount(${a.id})">Edit</button>
            <button class="btn btn-warn btn-sm" onclick="toggleAccount(${a.id})">${a.is_enabled?'Disable':'Enable'}</button>
            <button class="btn btn-danger btn-sm" onclick="deleteAccount(${a.id},'${esc(a.name)}')">Delete</button>
          </div>
        </td>
      </tr>`).join('');
  c.innerHTML = `
    <div class="section">
      <div class="section-header">
        <span class="section-title">MT5 Accounts (${_accounts.length})</span>
        <button class="btn btn-primary btn-sm" onclick="openAddAccount()">+ Add Account</button>
      </div>
      <div class="section-body" style="padding:0;">
        <div class="tbl-wrap">
          <table>
            <thead><tr><th>ID</th><th>Name</th><th>Login</th><th>Server</th><th>Role</th><th>State</th><th>Status</th><th>Last Seen</th><th>Actions</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>
    </div>`;
}

// ── Links ─────────────────────────────────────────────────────────────────────
async function renderLinks() {
  const [_lnk, _acc2] = await Promise.all([api('/links'), api('/accounts')]);
  if(_lnk===null || _acc2===null) return;
  _links = _lnk; _accounts = _acc2;
  const accMap = Object.fromEntries(_accounts.map(a=>[a.id, a]));
  const c = document.getElementById('page-content');
  const rows = _links.length === 0
    ? '<tr><td colspan="10"><div class="empty-state">No copier links yet.</div></td></tr>'
    : _links.map(l => {
      const m = accMap[l.master_account_id], s = accMap[l.slave_account_id];
      const mName = m ? m.name : '#'+l.master_account_id;
      const sName = s ? s.name : '#'+l.slave_account_id;
      const lot = l.fixed_lot != null ? l.fixed_lot+'L' : l.lot_multiplier+'x';
      const errHtml = l.last_error
        ? `<span class="text-red" title="${esc(l.last_error)}" style="cursor:help;">⚠ Error</span>`
        : '<span class="text-green">OK</span>';
      const retryHtml = l.next_retry_at
        ? `<div class="text-muted" style="font-size:11px;">retry ${fmtRelative(l.next_retry_at)}</div>` : '';
      return `
      <tr>
        <td class="td-mono">#${l.id}</td>
        <td class="td-name">${esc(l.name)}</td>
        <td>${esc(mName)}</td>
        <td>${esc(sName)}</td>
        <td class="td-mono">${esc(lot)}</td>
        <td style="white-space:nowrap;">${l.copy_sl?'SL':''} ${l.copy_tp?'TP':''} ${l.reverse_side?'<span class="pill" style="font-size:10px;">REV</span>':''}</td>
        <td><span class="pill ${l.is_active?'active':'paused'}"><span class="dot"></span>${l.is_active?'Active':'Paused'}</span></td>
        <td>${errHtml}${retryHtml}</td>
        <td class="text-muted" style="white-space:nowrap;">${fmtRelative(l.last_run_at)}</td>
        <td>
          <div class="actions-cell">
            <button class="btn btn-secondary btn-sm" onclick="openEditLink(${l.id})">Edit</button>
            <button class="btn btn-warn btn-sm" onclick="toggleLink(${l.id})">${l.is_active?'Pause':'Resume'}</button>
            <button class="btn btn-danger btn-sm" onclick="deleteLink(${l.id},'${esc(l.name)}')">Delete</button>
          </div>
        </td>
      </tr>`;
    }).join('');
  c.innerHTML = `
    <div class="section">
      <div class="section-header">
        <span class="section-title">Copier Links (${_links.length})</span>
        <button class="btn btn-primary btn-sm" onclick="openAddLink()">+ Add Link</button>
      </div>
      <div class="section-body" style="padding:0;">
        <div class="tbl-wrap">
          <table>
            <thead><tr><th>ID</th><th>Name</th><th>Master</th><th>Slave</th><th>Lot</th><th>Opts</th><th>State</th><th>Health</th><th>Last Run</th><th>Actions</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>
    </div>`;
}

// ── Mirrors ───────────────────────────────────────────────────────────────────
async function renderMirrors() {
  const data = await api('/mirrors?limit=500');
  if (data === null) return;
  const c = document.getElementById('page-content');
  const rows = data.length === 0
    ? '<tr><td colspan="10"><div class="empty-state">No mirrors yet.</div></td></tr>'
    : data.map(m => `
      <tr>
        <td class="td-mono">#${m.id}</td>
        <td class="td-mono">${m.link_id}</td>
        <td>${esc(m.symbol_master)}${m.symbol_slave!==m.symbol_master?' → '+esc(m.symbol_slave):''}</td>
        <td class="td-mono">${m.master_ticket}</td>
        <td class="td-mono">${m.slave_ticket}</td>
        <td class="td-mono">${m.volume_master} → ${m.volume_slave}</td>
        <td>${m.side_master===0?'<span class="text-green">BUY</span>':'<span class="text-red">SELL</span>'}</td>
        <td><span class="pill ${m.is_open?'active':'disabled'}">${m.is_open?'Open':'Closed'}</span></td>
        <td class="text-muted" style="white-space:nowrap;">${fmt(m.opened_at)}</td>
        <td>${m.is_open
          ? `<button class="btn btn-danger btn-sm" onclick="forceCloseMirror(${m.id})">Force Close</button>`
          : ''
        }</td>
      </tr>`).join('');
  c.innerHTML = `
    <div class="section">
      <div class="section-header">
        <span class="section-title">Position Mirrors (${data.length})</span>
        <span class="text-muted" style="font-size:12px;">${data.filter(m=>m.is_open).length} open</span>
      </div>
      <div class="section-body" style="padding:0;">
        <div class="tbl-wrap">
          <table>
            <thead><tr><th>ID</th><th>Link</th><th>Symbol</th><th>Master Ticket</th><th>Slave Ticket</th><th>Volume</th><th>Side</th><th>State</th><th>Opened</th><th>Action</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>
    </div>`;
}

async function forceCloseMirror(id) {
  if (!confirm('Mark this mirror as Closed in the database?\nThis does NOT close the actual MT5 position — only updates the app record.')) return;
  try {
    await api('/mirrors/' + id + '/close', {method: 'POST'});
    toast('Mirror marked as closed', 'success');
    renderMirrors();
  } catch(e) {
    toast(e.message, 'error');
  }
}

// ── Logs ──────────────────────────────────────────────────────────────────────
async function renderLogs() {
  const data = await api('/logs?limit=300'); if (data === null) return;
  const c = document.getElementById('page-content');
  c.innerHTML = `
    <div class="section">
      <div class="section-header">
        <span class="section-title">Event Logs (last 300)</span>
      </div>
      <div class="section-body" style="padding:12px 18px;">
        <div class="log-stream" id="logs-stream" style="height:60vh;">
          ${data.map(l=>logLine(l)).join('')}
        </div>
      </div>
    </div>`;
  const ls = document.getElementById('logs-stream');
  if(ls) ls.scrollTop = ls.scrollHeight;
}

// ── Workers ───────────────────────────────────────────────────────────────────
async function renderWorkers() {
  const data = await api('/workers'); if (data === null) return;
  const c = document.getElementById('page-content');
  const rows = data.length===0
    ? '<tr><td colspan="5"><div class="empty-state">No workers running.</div></td></tr>'
    : data.map(w=>`
      <tr>
        <td class="td-mono">${w.account_id}</td>
        <td>${_accounts.find(a=>a.id===w.account_id)?.name || '—'}</td>
        <td><span class="worker-dot ${w.alive?'ok':'err'}"></span> ${w.alive?'Alive':'Dead'}</td>
        <td><span class="pill ${w.connected?'active':'disabled'}">${w.connected?'Connected':'Disconnected'}</span></td>
        <td class="text-red" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;">${esc(w.last_error||'')}</td>
      </tr>`).join('');
  c.innerHTML = `
    <div class="section">
      <div class="section-header">
        <span class="section-title">MT5 Worker Pool (${data.length} workers)</span>
        <button class="btn btn-secondary btn-sm" onclick="renderWorkers()">Refresh</button>
      </div>
      <div class="section-body" style="padding:0;">
        <div class="tbl-wrap">
          <table>
            <thead><tr><th>Account ID</th><th>Name</th><th>Thread</th><th>MT5 Session</th><th>Last Error</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>
    </div>`;
}

// ── Log line helper ────────────────────────────────────────────────────────────
function logLine(l) {
  const ctx = l.context && Object.keys(l.context).length ? ' ' + JSON.stringify(l.context) : '';
  return `<div class="log-line"><span class="log-time">${fmt(l.created_at)}</span><span class="log-${l.level} log-msg">[${l.level}] ${esc(l.message)}${esc(ctx)}</span></div>`;
}

// ── Engine pill ────────────────────────────────────────────────────────────────
function updateEnginePill(running) {
  const pill = document.getElementById('engine-status-pill');
  const txt = document.getElementById('engine-state-text');
  if (!pill||!txt) return;
  pill.className = 'engine-pill' + (running?' running':'');
  txt.textContent = running ? 'Running' : 'Stopped';
}

// ── Account modal ─────────────────────────────────────────────────────────────
function openAddAccount() {
  document.getElementById('modal-account-title').textContent='Add Account';
  document.getElementById('edit-account-id').value='';
  document.getElementById('a-name').value='';
  document.getElementById('a-login').value='';
  document.getElementById('a-server').value='';
  document.getElementById('a-password').value='';
  document.getElementById('a-terminal').value='';
  document.getElementById('a-role').value='both';
  document.getElementById('a-enabled').checked=true;
  document.getElementById('a-err').textContent='';
  document.getElementById('modal-account').classList.add('open');
}
function openEditAccount(id) {
  const a = _accounts.find(x=>x.id===id); if(!a) return;
  document.getElementById('modal-account-title').textContent='Edit Account';
  document.getElementById('edit-account-id').value=id;
  document.getElementById('a-name').value=a.name;
  document.getElementById('a-login').value=a.login;
  document.getElementById('a-server').value=a.server;
  document.getElementById('a-password').value='';
  document.getElementById('a-terminal').value=a.terminal_path||'';
  document.getElementById('a-role').value=a.role_hint;
  document.getElementById('a-enabled').checked=a.is_enabled;
  document.getElementById('a-err').textContent='';
  document.getElementById('modal-account').classList.add('open');
}
async function submitAccountForm() {
  const id = document.getElementById('edit-account-id').value;
  const payload = {
    name: document.getElementById('a-name').value.trim(),
    login: Number(document.getElementById('a-login').value),
    server: document.getElementById('a-server').value.trim(),
    terminal_path: document.getElementById('a-terminal').value.trim()||null,
    role_hint: document.getElementById('a-role').value,
    is_enabled: document.getElementById('a-enabled').checked,
  };
  const pw = document.getElementById('a-password').value;
  if (pw) payload.password = pw;
  if (!id && !pw) { document.getElementById('a-err').textContent='Password is required'; return; }
  if (!payload.name) { document.getElementById('a-err').textContent='Name is required'; return; }
  if (!payload.login || !payload.server) { document.getElementById('a-err').textContent='Login and server are required'; return; }
  try {
    if (id) { await api('/accounts/'+id, {method:'PATCH', body:JSON.stringify(payload)}); toast('Account updated','success'); }
    else { await api('/accounts', {method:'POST', body:JSON.stringify(payload)}); toast('Account created','success'); }
    closeModal('modal-account');
    await renderAccounts();
  } catch(e) { document.getElementById('a-err').textContent=e.message; }
}
async function testAccount(id) {
  toast('Testing connection...','info');
  try {
    const r = await api('/accounts/'+id+'/test', {method:'POST'});
    if (r && r.ok) toast(`Connected: ${r.name} | Balance: ${r.balance} ${r.currency}`,'success');
    else toast('Test failed: '+(r&&r.error||'unknown'),'error');
    await renderAccounts();
  } catch(e) { toast('Test failed: '+e.message,'error'); }
}
async function toggleAccount(id) {
  try {
    await api('/accounts/'+id+'/toggle-enabled',{method:'POST'});
    toast('Account status updated','info');
    await renderAccounts();
  } catch(e) { toast(e.message,'error'); }
}
async function deleteAccount(id, name) {
  if(!confirm(`Delete account "${name}"?\nAll associated links will be deleted too.`)) return;
  try {
    await api('/accounts/'+id,{method:'DELETE'});
    toast('Account deleted','success');
    await renderAccounts();
  } catch(e) { toast(e.message,'error'); }
}

// ── Link modal ────────────────────────────────────────────────────────────────
function populateLinkSelects() {
  const masters = _accounts.filter(a=>a.role_hint==='master'||a.role_hint==='both');
  const slaves  = _accounts.filter(a=>a.role_hint==='slave'||a.role_hint==='both');
  const mkOpts = arr => arr.map(a=>`<option value="${a.id}">${esc(a.name)} (${a.login})</option>`).join('');
  document.getElementById('lk-master').innerHTML = mkOpts(masters);
  document.getElementById('lk-slave').innerHTML  = mkOpts(slaves);
}
async function openAddLink() {
  if (_accounts.length===0) _accounts = await api('/accounts')||[];
  document.getElementById('modal-link-title').textContent='Add Copier Link';
  document.getElementById('edit-link-id').value='';
  document.getElementById('lk-name').value='';
  document.getElementById('lk-multiplier').value='1.0';
  document.getElementById('lk-fixedlot').value='';
  document.getElementById('lk-symbolmap').value='{}';
  document.getElementById('lk-prefix').value='copier';
  document.getElementById('lk-copysl').checked=true;
  document.getElementById('lk-copytp').checked=true;
  document.getElementById('lk-reverse').checked=false;
  document.getElementById('lk-active').checked=true;
  document.getElementById('lk-err').textContent='';
  populateLinkSelects();
  document.getElementById('modal-link').classList.add('open');
}
async function openEditLink(id) {
  if (_accounts.length===0) _accounts = await api('/accounts')||[];
  const l = _links.find(x=>x.id===id); if(!l) return;
  document.getElementById('modal-link-title').textContent='Edit Copier Link';
  document.getElementById('edit-link-id').value=id;
  document.getElementById('lk-name').value=l.name;
  document.getElementById('lk-multiplier').value=l.lot_multiplier;
  document.getElementById('lk-fixedlot').value=l.fixed_lot||'';
  document.getElementById('lk-symbolmap').value=JSON.stringify(l.symbol_map,null,2);
  document.getElementById('lk-prefix').value=l.comment_prefix;
  document.getElementById('lk-copysl').checked=l.copy_sl;
  document.getElementById('lk-copytp').checked=l.copy_tp;
  document.getElementById('lk-reverse').checked=l.reverse_side;
  document.getElementById('lk-active').checked=l.is_active;
  document.getElementById('lk-err').textContent='';
  populateLinkSelects();
  document.getElementById('lk-master').value=l.master_account_id;
  document.getElementById('lk-slave').value=l.slave_account_id;
  document.getElementById('modal-link').classList.add('open');
}
async function submitLinkForm() {
  const id = document.getElementById('edit-link-id').value;
  let symbolMap;
  try { symbolMap = JSON.parse(document.getElementById('lk-symbolmap').value||'{}'); }
  catch { document.getElementById('lk-err').textContent='Invalid symbol map JSON'; return; }
  const fixedLotVal = document.getElementById('lk-fixedlot').value;
  const payload = {
    name: document.getElementById('lk-name').value.trim(),
    master_account_id: Number(document.getElementById('lk-master').value),
    slave_account_id:  Number(document.getElementById('lk-slave').value),
    lot_multiplier: Number(document.getElementById('lk-multiplier').value)||1,
    fixed_lot: fixedLotVal ? Number(fixedLotVal) : null,
    symbol_map: symbolMap,
    comment_prefix: document.getElementById('lk-prefix').value,
    copy_sl: document.getElementById('lk-copysl').checked,
    copy_tp: document.getElementById('lk-copytp').checked,
    reverse_side: document.getElementById('lk-reverse').checked,
    is_active: document.getElementById('lk-active').checked,
  };
  if (!payload.name) { document.getElementById('lk-err').textContent='Name is required'; return; }
  try {
    if (id) { await api('/links/'+id,{method:'PATCH',body:JSON.stringify(payload)}); toast('Link updated','success'); }
    else { await api('/links',{method:'POST',body:JSON.stringify(payload)}); toast('Link created','success'); }
    closeModal('modal-link');
    await renderLinks();
  } catch(e) { document.getElementById('lk-err').textContent=e.message; }
}
async function toggleLink(id) {
  try {
    await api('/links/'+id+'/toggle',{method:'POST'});
    toast('Link status updated','info');
    await renderLinks();
  } catch(e) { toast(e.message,'error'); }
}
async function deleteLink(id,name) {
  if(!confirm(`Delete link "${name}"?`)) return;
  try {
    await api('/links/'+id,{method:'DELETE'});
    toast('Link deleted','success');
    await renderLinks();
  } catch(e) { toast(e.message,'error'); }
}

// ── Modal helpers ─────────────────────────────────────────────────────────────
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal-backdrop').forEach(m => {
  m.addEventListener('click', e => { if(e.target===m) m.classList.remove('open'); });
});

// ── WebSocket live logs ────────────────────────────────────────────────────────
let _wsFailCount = 0;

function connectWs() {
  if (_wsReconnectTimer) { clearTimeout(_wsReconnectTimer); _wsReconnectTimer=null; }
  const ind = document.getElementById('ws-indicator');

  // Don't attempt WS if not logged in
  if (!_token) return;

  // Close any existing connection cleanly
  if (_ws && _ws.readyState < 2) {
    try { _ws.close(); } catch {}
    _ws = null;
  }

  const scheme = location.protocol==='https:'?'wss':'ws';
  try {
    _ws = new WebSocket(`${scheme}://${location.host}/ws`);
  } catch(e) {
    _scheduleWsReconnect(ind);
    return;
  }

  _ws.onopen = () => {
    _wsFailCount = 0;
  };

  _ws.onmessage = (evt) => {
    try {
      const msg = JSON.parse(evt.data);
      if (msg.type==='auth_required') {
        // Send token if available, otherwise try cookie session
        const tok = _token || '';
        _ws.send(JSON.stringify({token: tok}));
        return;
      }
      if (msg.type==='hello') {
        _wsFailCount = 0;
        if(ind) { ind.textContent='⬤ live'; ind.style.color='var(--green)'; }
        return;
      }
      if (msg.type==='auth_failed') {
        _ws.close();
        showLogin();
        return;
      }
      // Push log line to any visible log streams
      const line = logLine(msg);
      ['overview-log-stream','logs-stream'].forEach(id=>{
        const el=document.getElementById(id);
        if(el){el.insertAdjacentHTML('beforeend',line); el.scrollTop=el.scrollHeight;}
      });
    } catch {}
  };

  let _heartbeatTimer = null;

  function resetHeartbeat() {
    if (_heartbeatTimer) clearTimeout(_heartbeatTimer);
    _heartbeatTimer = setTimeout(() => {
      // No message received in 30s — connection likely frozen
      try { _ws.close(); } catch {}
    }, 30000);
  }

  _ws.onopen = () => {
    _wsFailCount = 0;
    resetHeartbeat();
  };

  const _origOnMessage = _ws.onmessage;

  _ws.addEventListener('message', () => resetHeartbeat());

  _ws.onclose = (evt) => {
    _wsFailCount++;
    if (_heartbeatTimer) clearTimeout(_heartbeatTimer);
    if(ind) { ind.textContent='⬤ offline'; ind.style.color='var(--text3)'; }
    _scheduleWsReconnect(ind);
  };

  _ws.onerror = () => {
    try { _ws.close(); } catch {}
  };
}

function _scheduleWsReconnect(ind) {
  // Fast reconnect: 500ms first 3 tries, then 2s, then 5s max
  const delay = _wsFailCount <= 3 ? 500 : _wsFailCount <= 6 ? 2000 : 5000;
  if(ind) { ind.textContent=`⬤ offline (retry ${_wsFailCount})`; ind.style.color='var(--text3)'; }
  _wsReconnectTimer = setTimeout(connectWs, delay);
}

// ── Boot ──────────────────────────────────────────────────────────────────────
async function boot() {
  try {
    // Exchange cookie session for a fresh Bearer token so all API calls
    // and WebSocket auth work correctly after a browser refresh.
    const r = await fetch('/api/auth/token', {
      method: 'POST',
      credentials: 'include',
      headers: {'Content-Type': 'application/json'}
    });
    if (r.ok) {
      const d = await r.json();
      _token = d.access_token;   // store token — used for Bearer + WS auth
      showApp();
      navigate('overview', document.querySelector('[data-page="overview"]'));
      connectWs();
      return;
    }
  } catch {}
  // No valid session — show login
  showLogin();
}
boot();
</script>
</body>
</html>
"""
