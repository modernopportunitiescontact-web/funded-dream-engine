"""
app/db/base.py
--------------
Shared DeclarativeBase for all ORM models.
All model modules must be imported before Base.metadata.create_all() is called.
"""
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass
