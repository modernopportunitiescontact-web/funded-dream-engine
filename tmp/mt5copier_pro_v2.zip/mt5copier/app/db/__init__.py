"""
app/db/__init__.py
------------------
Import all models here so that Alembic autogenerate and
Base.metadata.create_all() can discover every table.
"""
from app.db.base import Base
from app.models import account, copier_link, position_mirror, event_log  # noqa: F401

__all__ = ["Base"]
