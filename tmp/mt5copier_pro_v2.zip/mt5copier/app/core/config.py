"""
app/core/config.py
------------------
Central configuration loaded from environment variables.
All secrets and tunable parameters live here.
"""
from __future__ import annotations

import base64
import hashlib
import os
from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ─────────────────────────────────────────────────────────
    APP_NAME: str = "MT5 Copier Pro"
    APP_VERSION: str = "2.0.0"
    DEBUG: bool = False

    # ── Security ─────────────────────────────────────────────────────────────
    APP_SECRET: str = "change-me-in-production-min-32-chars!!"
    # Dashboard admin credentials (change in production)
    ADMIN_USERNAME: str = "admin"
    ADMIN_PASSWORD: str = "changeme"
    # JWT session token TTL in minutes
    SESSION_TTL_MINUTES: int = 480  # 8 hours

    # ── Database ─────────────────────────────────────────────────────────────
    DATABASE_URL: str = "sqlite:///./copier.db"

    # ── MT5 / Copier Engine ───────────────────────────────────────────────────
    # Seconds between each full engine poll cycle — 0.5s for near-realtime copy
    POLL_INTERVAL_SECONDS: float = 0.5
    # MT5 order slippage in points
    DEFAULT_DEVIATION: int = 20
    # Magic number stamped on all copied orders
    MAGIC_NUMBER: int = 880055
    # Initial cooldown seconds after a link error
    LINK_ERROR_COOLDOWN_SECONDS: int = 20
    # Maximum cooldown cap (exponential backoff capped here)
    LINK_ERROR_COOLDOWN_MAX_SECONDS: int = 300
    # Seconds to wait for an MT5 operation before timing out
    # 15s gives enough room for slow broker connections
    MT5_OPERATION_TIMEOUT_SECONDS: float = 15.0

    # Seconds between keepalive checks when worker is idle
    MT5_KEEPALIVE_INTERVAL_SECONDS: float = 60.0
    # No hard limit on number of accounts/workers.
    # Each account gets one dedicated thread. Scale as needed.

    # ── CORS ─────────────────────────────────────────────────────────────────
    CORS_ORIGINS: List[str] = ["http://localhost:8000", "http://127.0.0.1:8000"]

    # ── Derived helpers ──────────────────────────────────────────────────────
    @property
    def fernet_key(self) -> bytes:
        """Derive a stable 32-byte Fernet key from APP_SECRET."""
        digest = hashlib.sha256(self.APP_SECRET.encode("utf-8")).digest()
        return base64.urlsafe_b64encode(digest)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
