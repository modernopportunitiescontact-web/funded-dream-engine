"""
app/core/logging.py
-------------------
Structured logging setup.
- Python stdlib logging is configured for structured output.
- log_event() persists an EventLog row AND broadcasts to WebSocket clients.
- Passwords and sensitive keys are scrubbed from log contexts.
"""
from __future__ import annotations

import json
import logging
import logging.config
from datetime import datetime, timezone
from typing import Any, Dict

_SENSITIVE_KEYS = {"password", "password_enc", "secret", "token", "api_key"}

# ── stdlib logger config ──────────────────────────────────────────────────────

LOGGING_CONFIG: Dict[str, Any] = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {
            "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "standard",
            "stream": "ext://sys.stdout",
        },
    },
    "root": {
        "level": "INFO",
        "handlers": ["console"],
    },
    "loggers": {
        "uvicorn": {"propagate": True},
        "sqlalchemy.engine": {"level": "WARNING", "propagate": True},
    },
}


def configure_logging() -> None:
    logging.config.dictConfig(LOGGING_CONFIG)


logger = logging.getLogger("mt5copier")


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)


def safe_context(**kwargs: Any) -> Dict[str, Any]:
    """Strip sensitive keys from a context dict before logging/storing."""
    return {k: v for k, v in kwargs.items() if k.lower() not in _SENSITIVE_KEYS}


def log_event(level: str, message: str, **context: Any) -> None:
    """
    Persist an EventLog to the database and broadcast it via WebSocket.
    This function is safe to call from background threads.
    """
    from app.db.session import SessionLocal
    from app.models.event_log import EventLog

    payload = safe_context(**context)
    lvl = level.upper()

    # 1. Persist to DB
    try:
        with SessionLocal() as db:
            db.add(EventLog(level=lvl, message=message, context_json=json_dumps(payload)))
            db.commit()
    except Exception as exc:
        logger.error("log_event DB write failed: %s", exc)

    # 2. Emit to stdlib logger
    log_fn = getattr(logger, lvl.lower(), logger.info)
    log_fn("%s | %s", message, payload)

    # 3. Broadcast to WebSocket hub (non-blocking, best-effort)
    try:
        import asyncio
        from app.core.state import get_app_state

        state = get_app_state()
        loop = state.main_loop
        hub = state.ws_hub
        if loop is not None and hub is not None and loop.is_running():
            asyncio.run_coroutine_threadsafe(
                hub.broadcast(
                    {
                        "type": "log",
                        "level": lvl,
                        "message": message,
                        "context": payload,
                        "created_at": now_utc().isoformat(),
                    }
                ),
                loop,
            )
    except Exception:
        pass
