"""
app/core/security.py
--------------------
Encryption helpers for storing MT5 passwords at rest,
and JWT-based session tokens for the admin dashboard.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken
from jose import JWTError, jwt

from app.core.config import get_settings

_settings = get_settings()


# ── Fernet symmetric encryption ──────────────────────────────────────────────

def _fernet() -> Fernet:
    return Fernet(_settings.fernet_key)


def encrypt_secret(value: str) -> str:
    """Encrypt a plaintext string (password) for storage in the DB."""
    return _fernet().encrypt(value.encode("utf-8")).decode("utf-8")


def decrypt_secret(value: str) -> str:
    """Decrypt a previously encrypted string. Raises RuntimeError on failure."""
    try:
        return _fernet().decrypt(value.encode("utf-8")).decode("utf-8")
    except InvalidToken as exc:
        raise RuntimeError(
            "Cannot decrypt account password. "
            "Check that APP_SECRET has not changed since the account was saved."
        ) from exc


# ── JWT session tokens ────────────────────────────────────────────────────────

_ALGORITHM = "HS256"
_TOKEN_TYPE = "bearer"


def create_access_token(username: str) -> str:
    """Create a signed JWT valid for SESSION_TTL_MINUTES."""
    expire = datetime.now(timezone.utc) + timedelta(minutes=_settings.SESSION_TTL_MINUTES)
    payload = {"sub": username, "exp": expire, "type": _TOKEN_TYPE}
    return jwt.encode(payload, _settings.APP_SECRET, algorithm=_ALGORITHM)


def verify_access_token(token: str) -> Optional[str]:
    """Return the username if token is valid, otherwise None."""
    try:
        data = jwt.decode(token, _settings.APP_SECRET, algorithms=[_ALGORITHM])
        return data.get("sub")
    except JWTError:
        return None


def verify_admin_credentials(username: str, password: str) -> bool:
    """Constant-time comparison of admin credentials."""
    import hmac
    ok_user = hmac.compare_digest(username, _settings.ADMIN_USERNAME)
    ok_pass = hmac.compare_digest(password, _settings.ADMIN_PASSWORD)
    return ok_user and ok_pass
