"""
app/core/state.py
-----------------
A singleton that holds shared runtime state that needs to be accessible
from both async FastAPI handlers and sync background threads:
  - the asyncio event loop reference (for thread -> async bridging)
  - the WebSocket broadcast hub
"""
from __future__ import annotations

import asyncio
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from app.core.websocket_hub import WebSocketHub


class AppState:
    def __init__(self) -> None:
        self.main_loop: Optional[asyncio.AbstractEventLoop] = None
        self.ws_hub: Optional["WebSocketHub"] = None


_state = AppState()


def get_app_state() -> AppState:
    return _state
