"""
app/core/websocket_hub.py
-------------------------
Async-safe broadcast hub for WebSocket clients.
Used to push live log events and copier status updates to the dashboard.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Set

from fastapi import WebSocket

logger = logging.getLogger("mt5copier.ws")


class WebSocketHub:
    def __init__(self) -> None:
        self._clients: Set[WebSocket] = set()
        self._lock = asyncio.Lock()

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        async with self._lock:
            self._clients.add(websocket)
        logger.debug("WS client connected. Total: %d", len(self._clients))

    async def disconnect(self, websocket: WebSocket) -> None:
        async with self._lock:
            self._clients.discard(websocket)
        logger.debug("WS client disconnected. Total: %d", len(self._clients))

    async def broadcast(self, payload: Dict[str, Any]) -> None:
        dead: List[WebSocket] = []
        async with self._lock:
            clients = list(self._clients)

        for client in clients:
            try:
                await client.send_json(payload)
            except Exception:
                dead.append(client)

        if dead:
            async with self._lock:
                for client in dead:
                    self._clients.discard(client)

    @property
    def client_count(self) -> int:
        return len(self._clients)
