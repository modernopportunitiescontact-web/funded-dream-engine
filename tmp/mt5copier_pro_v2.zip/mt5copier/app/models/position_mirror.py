"""
app/models/position_mirror.py
-----------------------------
Tracks each master position that has been mirrored to a slave.
This table is the source of truth for duplicate-copy prevention
and restart recovery.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean, DateTime, Float, ForeignKey,
    Index, Integer, String, UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.logging import now_utc
from app.db.base import Base


class PositionMirror(Base):
    __tablename__ = "position_mirrors"
    __table_args__ = (
        # Each master ticket should only have ONE active mirror per link
        UniqueConstraint(
            "link_id", "master_ticket",
            name="uq_mirrors_link_master_ticket",
        ),
        Index("ix_mirrors_link_open", "link_id", "is_open"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    link_id: Mapped[int] = mapped_column(
        ForeignKey("copier_links.id", ondelete="CASCADE"), nullable=False, index=True
    )

    master_ticket: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    slave_ticket: Mapped[int] = mapped_column(Integer, nullable=False)

    symbol_master: Mapped[str] = mapped_column(String(64), nullable=False)
    symbol_slave: Mapped[str] = mapped_column(String(64), nullable=False)

    volume_master: Mapped[float] = mapped_column(Float, nullable=False)
    volume_slave: Mapped[float] = mapped_column(Float, nullable=False)

    # 0 = BUY, 1 = SELL (MT5 POSITION_TYPE_* constants)
    side_master: Mapped[int] = mapped_column(Integer, nullable=False)

    is_open: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    opened_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=now_utc
    )
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Soft error tracking for this specific mirror
    last_error: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)

    link: Mapped["CopierLink"] = relationship(  # type: ignore[name-defined]  # noqa: F821
        "CopierLink",
        back_populates="mirrors",
    )

    def __repr__(self) -> str:
        return (
            f"<PositionMirror id={self.id} "
            f"master={self.master_ticket} slave={self.slave_ticket} "
            f"open={self.is_open}>"
        )
