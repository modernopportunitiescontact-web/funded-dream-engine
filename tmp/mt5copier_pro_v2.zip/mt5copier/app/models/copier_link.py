"""
app/models/copier_link.py
-------------------------
A Copier Link defines the relationship between one master account
and one slave account, including all copy parameters.
"""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from sqlalchemy import (
    Boolean, DateTime, Float, ForeignKey, Index,
    Integer, String, Text, UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.logging import now_utc
from app.db.base import Base


class CopierLink(Base):
    __tablename__ = "copier_links"
    __table_args__ = (
        UniqueConstraint("name", name="uq_copier_links_name"),
        # Prevent duplicate master->slave pairs
        UniqueConstraint("master_account_id", "slave_account_id", name="uq_copier_links_pair"),
        Index("ix_copier_links_active", "is_active"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False, index=True)

    master_account_id: Mapped[int] = mapped_column(
        ForeignKey("accounts.id", ondelete="CASCADE"), nullable=False, index=True
    )
    slave_account_id: Mapped[int] = mapped_column(
        ForeignKey("accounts.id", ondelete="CASCADE"), nullable=False, index=True
    )

    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # JSON dict: {"EURUSD": "EURUSDs", ...}
    symbol_map_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")

    lot_multiplier: Mapped[float] = mapped_column(Float, nullable=False, default=1.0)
    fixed_lot: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    copy_sl: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    copy_tp: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    reverse_side: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    comment_prefix: Mapped[str] = mapped_column(String(40), nullable=False, default="copier")

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=now_utc
    )
    last_run_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)

    # Exponential backoff state
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    next_retry_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    master_account: Mapped["Account"] = relationship(  # type: ignore[name-defined]  # noqa: F821
        "Account",
        foreign_keys=[master_account_id],
        back_populates="master_links",
    )
    slave_account: Mapped["Account"] = relationship(  # type: ignore[name-defined]  # noqa: F821
        "Account",
        foreign_keys=[slave_account_id],
        back_populates="slave_links",
    )
    mirrors: Mapped[List["PositionMirror"]] = relationship(  # type: ignore[name-defined]  # noqa: F821
        "PositionMirror",
        back_populates="link",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        return f"<CopierLink id={self.id} name={self.name!r} active={self.is_active}>"
