"""
app/models/account.py
---------------------
MT5 trading account stored in the database.
Passwords are stored AES-encrypted via Fernet.
"""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from sqlalchemy import Boolean, DateTime, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.logging import now_utc
from app.db.base import Base


class Account(Base):
    __tablename__ = "accounts"
    __table_args__ = (
        Index("ix_accounts_login_server", "login", "server"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False, index=True)
    login: Mapped[int] = mapped_column(Integer, nullable=False)
    server: Mapped[str] = mapped_column(String(255), nullable=False)
    # Fernet-encrypted MT5 password
    password_enc: Mapped[str] = mapped_column(Text, nullable=False)
    # Optional path to the MT5 terminal executable
    terminal_path: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    # hint to the UI: master / slave / both
    role_hint: Mapped[str] = mapped_column(String(20), nullable=False, default="both")
    is_enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    last_status: Mapped[str] = mapped_column(String(255), nullable=False, default="never tested")
    last_seen_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=now_utc
    )

    # Relationships - cascade delete clears links when account is deleted
    master_links: Mapped[List["CopierLink"]] = relationship(  # type: ignore[name-defined]  # noqa: F821
        "CopierLink",
        foreign_keys="CopierLink.master_account_id",
        back_populates="master_account",
        cascade="all, delete-orphan",
    )
    slave_links: Mapped[List["CopierLink"]] = relationship(  # type: ignore[name-defined]  # noqa: F821
        "CopierLink",
        foreign_keys="CopierLink.slave_account_id",
        back_populates="slave_account",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        return f"<Account id={self.id} login={self.login} server={self.server!r}>"
