"""
app/models/event_log.py
-----------------------
Structured audit/event log persisted to the database.
Every significant copier action is logged here for admin visibility.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.logging import now_utc
from app.db.base import Base


class EventLog(Base):
    __tablename__ = "event_logs"
    __table_args__ = (
        Index("ix_event_logs_level_created", "level", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    # INFO / WARNING / ERROR / DEBUG
    level: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    # Serialised JSON context dict (passwords scrubbed)
    context_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=now_utc, index=True
    )

    def __repr__(self) -> str:
        return f"<EventLog id={self.id} level={self.level!r} msg={self.message[:40]!r}>"
