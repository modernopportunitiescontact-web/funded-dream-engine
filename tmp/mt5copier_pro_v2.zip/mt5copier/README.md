# MT5 Copier Pro v2.0

A production-grade, multi-account MetaTrader 5 trade copier with a professional web dashboard.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [MT5 Session Strategy](#mt5-session-strategy)
3. [Project Structure](#project-structure)
4. [Quick Start (Windows)](#quick-start-windows)
5. [Configuration](#configuration)
6. [Running the Application](#running-the-application)
7. [Database Migrations](#database-migrations)
8. [Dashboard Guide](#dashboard-guide)
9. [API Reference](#api-reference)
10. [Production Notes](#production-notes)
11. [Troubleshooting](#troubleshooting)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         FastAPI Server                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐   │
│  │  /api/   │  │  /api/   │  │  /api/   │  │  WebSocket   │   │
│  │ accounts │  │  links   │  │ monitor  │  │    /ws       │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────────┘   │
│         │             │             │                           │
│         └─────────────┴─────────────┘                          │
│                        │                                        │
│               ┌────────────────┐                               │
│               │  Service Layer │                               │
│               └────────────────┘                               │
│                        │                                        │
│               ┌────────────────┐                               │
│               │ SQLite / PgSQL │  (SQLAlchemy + Alembic)       │
│               └────────────────┘                               │
└──────────────────────────┬──────────────────────────────────────┘
                           │
              ┌────────────────────────┐
              │     CopierEngine       │  (background thread)
              │   polls every 3s       │
              └────────────┬───────────┘
                           │
              ┌────────────────────────┐
              │     WorkerPool         │
              │  1 worker per account  │
              └────────────┬───────────┘
                           │
         ┌─────────────────┼─────────────────┐
         │                 │                 │
  ┌──────────┐      ┌──────────┐      ┌──────────┐
  │ Worker-1 │      │ Worker-2 │      │ Worker-N │
  │ Thread   │      │ Thread   │      │ Thread   │
  │ Account1 │      │ Account2 │      │ AccountN │
  │ MT5 Sess │      │ MT5 Sess │      │ MT5 Sess │
  └──────────┘      └──────────┘      └──────────┘
```

---

## MT5 Session Strategy

### The Problem with the Legacy Approach

The MetaTrader5 Python package (`mt5.initialize()`) operates on **global DLL state** inside the Windows process. In the legacy `monapp.py`, a single `threading.RLock` serialised all MT5 calls but still did `initialize() → operations → shutdown()` per account per cycle. This has several critical problems:

1. **Sequential bottleneck**: with 30+ accounts, each poll cycle must wait for every account to complete before moving to the next.
2. **Race condition at shutdown**: if `shutdown()` is called while another thread is reading positions, the DLL context is corrupted.
3. **Connection instability**: repeatedly calling `initialize()` for different accounts within one session is not guaranteed to cleanly switch contexts on all broker terminals.

### The Solution: Per-Account Dedicated Worker Threads

Each MT5 account gets **exactly one `AccountWorker` thread** that:

- Owns a **single persistent MT5 connection** for its lifetime
- Accepts callable tasks via a **thread-safe queue** (`queue.Queue`)
- Returns results via `concurrent.futures.Future` — callers can await results or set timeouts
- **Never shares** MT5 global state with any other thread
- Performs automatic reconnection on connection loss

```
CopierEngine submits task:
  future = worker.submit(lambda: MT5Adapter.get_positions())
  positions = future.result(timeout=10)   # blocks calling thread safely
```

### What This Means in Practice for 30+ Accounts

| Scenario | Legacy | v2.0 |
|----------|--------|-------|
| 30 accounts polling simultaneously | ❌ Serialised (one at a time) | ✅ All parallel |
| Account cross-talk risk | ❌ High (shared lock) | ✅ Zero (isolated threads) |
| Connection drop recovery | ❌ No retry | ✅ Auto-reconnect with backoff |
| Account added at runtime | ❌ Requires restart | ✅ Worker starts dynamically |
| Crashproof on MT5 error | ❌ Kills whole engine | ✅ Isolated per account |

### MT5 Terminal Requirements

- **One MT5 terminal per account** is the safest configuration.
- If accounts share the same broker server, they may share a terminal — but connection switching is handled by the worker's `initialize()` call before each operation.
- Specify `terminal_path` per account when multiple MT5 installations exist (e.g. different brokers).
- All terminals must be running before the copier starts, or must be auto-launched by the MT5 Python API.

---

## Project Structure

```
mt5copier/
├── app/
│   ├── core/
│   │   ├── config.py          # All settings via pydantic-settings
│   │   ├── security.py        # Fernet encryption + JWT tokens
│   │   ├── logging.py         # Structured logging + WS broadcast
│   │   ├── state.py           # Global app state singleton
│   │   └── websocket_hub.py   # Async WebSocket broadcast hub
│   ├── db/
│   │   ├── base.py            # SQLAlchemy DeclarativeBase
│   │   └── session.py         # Engine + SessionLocal factory
│   ├── models/
│   │   ├── account.py         # MT5 Account ORM model
│   │   ├── copier_link.py     # CopierLink ORM model
│   │   ├── position_mirror.py # PositionMirror ORM model
│   │   └── event_log.py       # EventLog ORM model
│   ├── schemas/
│   │   ├── account.py         # Pydantic schemas for Account
│   │   ├── copier_link.py     # Pydantic schemas for CopierLink
│   │   └── common.py          # Shared schemas (mirrors, logs, status)
│   ├── mt5/
│   │   ├── types.py           # Pure data types (PositionSnapshot, etc.)
│   │   ├── adapter.py         # MT5 static method layer
│   │   ├── worker.py          # Per-account dedicated thread worker
│   │   └── pool.py            # WorkerPool singleton
│   ├── copier/
│   │   └── engine.py          # CopierEngine background thread
│   ├── services/
│   │   ├── account_service.py # Account business logic
│   │   └── link_service.py    # Link business logic
│   ├── api/
│   │   ├── deps.py            # FastAPI dependencies (db, auth)
│   │   └── routes/
│   │       ├── auth.py        # Login / logout / session
│   │       ├── accounts.py    # Account CRUD + test
│   │       ├── links.py       # Link CRUD + toggle
│   │       ├── monitoring.py  # Health, status, logs, mirrors
│   │       └── ws.py          # WebSocket live log stream
│   ├── frontend/
│   │   └── renderer.py        # Full dashboard HTML (SPA)
│   └── main.py                # FastAPI app factory + lifespan
├── alembic/
│   ├── env.py
│   ├── script.py.mako
│   └── versions/
├── alembic.ini
├── requirements.txt
├── .env.example
├── run.py
└── README.md
```

---

## Quick Start (Windows)

### Prerequisites

- Windows 10/11 (required for MetaTrader5 Python package)
- Python 3.11+ ([python.org](https://python.org))
- MetaTrader 5 terminal(s) installed and running
- Git (optional)

### Step 1: Create a virtual environment

```powershell
cd C:\projects
python -m venv mt5copier-env
mt5copier-env\Scripts\activate
```

### Step 2: Clone / download the project

```powershell
# If using git:
git clone <repo-url> mt5copier
cd mt5copier

# Or download and extract the zip, then:
cd mt5copier
```

### Step 3: Install dependencies

```powershell
pip install -r requirements.txt
pip install MetaTrader5
```

### Step 4: Configure

```powershell
copy .env.example .env
notepad .env
```

Change at minimum:
- `APP_SECRET` → a long random string (e.g. 48 characters)
- `ADMIN_PASSWORD` → your dashboard password

### Step 5: Run

```powershell
python run.py
```

Open your browser at **http://127.0.0.1:8000**

---

## Configuration

All configuration is done via environment variables in `.env`. See `.env.example` for the full list with descriptions.

| Variable | Default | Description |
|----------|---------|-------------|
| `APP_SECRET` | `change-me...` | **MUST CHANGE** — derives encryption key |
| `ADMIN_USERNAME` | `admin` | Dashboard login username |
| `ADMIN_PASSWORD` | `changeme` | **MUST CHANGE** — dashboard password |
| `DATABASE_URL` | `sqlite:///./copier.db` | SQLAlchemy database URL |
| `POLL_INTERVAL_SECONDS` | `3.0` | Engine poll frequency |
| `DEFAULT_DEVIATION` | `20` | MT5 order slippage (points) |
| `MAGIC_NUMBER` | `880055` | Magic number on copied orders |
| `LINK_ERROR_COOLDOWN_SECONDS` | `20` | Initial backoff after link error |
| `LINK_ERROR_COOLDOWN_MAX_SECONDS` | `300` | Maximum backoff cap |
| `MT5_OPERATION_TIMEOUT_SECONDS` | `10.0` | Per-operation MT5 timeout |

---

## Running the Application

### Development (with auto-reload)

```powershell
python run.py --reload
```

### Production (stable, no reload)

```powershell
python run.py --host 0.0.0.0 --port 8000
```

### Custom port

```powershell
python run.py --port 9000
```

---

## Database Migrations

The application auto-creates all tables on first startup using `Base.metadata.create_all()`. This is sufficient for local development.

For production with schema evolution, use Alembic:

```powershell
# Create initial migration
alembic revision --autogenerate -m "initial schema"

# Apply migrations
alembic upgrade head

# Check current revision
alembic current

# Downgrade one step
alembic downgrade -1
```

---

## Dashboard Guide

### Login

Navigate to `http://localhost:8000`. Enter your admin credentials from `.env`.

### Overview

- Shows live counts: total accounts, active links, open mirrors, engine state
- Recent event log stream (auto-updated via WebSocket)

### Accounts

- **Add Account**: Enter MT5 login, server, password, optional terminal path
- **Test**: Connects to MT5 and shows balance/equity
- **Edit**: Update credentials (password field optional — leave blank to keep current)
- **Enable/Disable**: Pauses all copying involving this account
- **Delete**: Only allowed if no links reference this account

### Copier Links

- **Add Link**: Select master + slave accounts, configure lot sizing, SL/TP copying
- **Lot settings**: Either use `Lot Multiplier` (e.g. `0.5` = half size) or `Fixed Lot` (overrides multiplier)
- **Symbol Map**: JSON dict to remap symbol names — e.g. `{"EURUSD": "EURUSDs"}`
- **Pause/Resume**: Temporarily stops copying without deleting history
- **Delete**: Removes link and all associated mirror records

### Mirrors

Live view of all position mirror records — shows which master tickets map to which slave tickets, volumes, and state (Open/Closed).

### Event Logs

Full structured event log. All copy open/close/modify operations are logged with context.

### Workers

Shows the MT5 worker thread status per account — useful for debugging connection issues.

---

## API Reference

All API endpoints require authentication via:
- `Authorization: Bearer <token>` header, or
- `session_token` HttpOnly cookie (set automatically by browser after login)

### Auth

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/auth/login` | `{username, password}` → `{access_token}` |
| `POST` | `/api/auth/logout` | Clears session cookie |
| `GET` | `/api/auth/me` | Returns current user info |

### Accounts

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/accounts` | List all accounts |
| `POST` | `/api/accounts` | Create account |
| `PATCH` | `/api/accounts/{id}` | Update account |
| `DELETE` | `/api/accounts/{id}` | Delete account |
| `POST` | `/api/accounts/{id}/toggle-enabled` | Enable/disable |
| `POST` | `/api/accounts/{id}/test` | Test MT5 connection |

### Links

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/links` | List all links |
| `POST` | `/api/links` | Create link |
| `PATCH` | `/api/links/{id}` | Update link |
| `DELETE` | `/api/links/{id}` | Delete link |
| `POST` | `/api/links/{id}/toggle` | Pause/resume |

### Monitoring

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/health` | Liveness check (no auth required) |
| `GET` | `/api/status` | Full dashboard metrics |
| `GET` | `/api/logs?limit=100&level=ERROR` | Event logs |
| `GET` | `/api/mirrors?open_only=true` | Position mirrors |
| `GET` | `/api/workers` | MT5 worker pool status |

### WebSocket

`ws://localhost:8000/ws` — Authenticated via first-message JSON `{token: "..."}`.

---

## Production Notes

### Security

1. **Change `APP_SECRET`**: Changing this after accounts are saved will make all stored passwords unreadable. Choose it once and never change it.
2. **Change `ADMIN_PASSWORD`**: The default `changeme` is not secure.
3. **Bind to localhost**: When running locally, bind to `127.0.0.1` (the default) not `0.0.0.0` unless you have a reverse proxy in front.
4. **HTTPS**: Put Nginx or Caddy in front if exposing externally. Set `secure=True` on the session cookie in `auth.py`.

### Database

For production with multiple concurrent users, switch to PostgreSQL:

```env
DATABASE_URL=postgresql://user:password@localhost:5432/mt5copier
```

Install the driver: `pip install psycopg2-binary`

### Performance with 30+ Accounts

- Each account uses one dedicated thread. With 30+ accounts you will have 30+ threads running concurrently.
- Each thread holds one MT5 terminal connection — ensure sufficient system resources.
- `POLL_INTERVAL_SECONDS=3.0` is a good starting point. Lower values (1–2s) give faster copy latency but increase MT5 load.
- Monitor the Workers page to check connection health per account.

### Windows Service

To run as a Windows service, use [NSSM](https://nssm.cc/):

```powershell
nssm install MT5CopierPro "C:\path\to\python.exe" "C:\path\to\mt5copier\run.py"
nssm set MT5CopierPro AppDirectory "C:\path\to\mt5copier"
nssm start MT5CopierPro
```

---

## Troubleshooting

### "Cannot decrypt account password. Check APP_SECRET."

You changed `APP_SECRET` after saving accounts. You must re-add the accounts with their passwords.

### "MT5 initialize failed"

- Ensure the MT5 terminal is running and logged in (or allow API to auto-login).
- Check the `terminal_path` is correct if set.
- Verify login/server/password are correct by clicking "Test" in the dashboard.

### Worker shows "Dead" in Workers page

The worker thread crashed. Check the Event Logs page for the error detail. Common causes:
- MT5 terminal was closed
- Wrong credentials
- Server name typo

### Positions not being copied

1. Check the link is Active (not Paused) in Copier Links.
2. Check both accounts are Enabled.
3. Check Event Logs for errors.
4. Check the master account actually has open positions.
5. Check the slave account's broker supports the symbol (use Symbol Map if needed).

### "A link between this master and slave already exists"

Each master→slave pair can only have one link. If you need different settings, delete the existing link first.
