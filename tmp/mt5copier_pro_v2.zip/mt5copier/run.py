"""
run.py
------
Entry point for running MT5 Copier Pro locally on Windows.

Usage:
    python run.py
    python run.py --port 8080
    python run.py --reload          (dev mode, auto-reloads on code changes)
"""
from __future__ import annotations

import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description="MT5 Copier Pro")
    parser.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (dev only)")
    args = parser.parse_args()

    try:
        import uvicorn
    except ImportError:
        print("ERROR: uvicorn is not installed. Run: pip install -r requirements.txt")
        sys.exit(1)

    print(f"Starting MT5 Copier Pro at http://{args.host}:{args.port}")
    print("Open your browser at that address to access the dashboard.\n")

    uvicorn.run(
        "app.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        reload_dirs=["app"] if args.reload else None,
        log_level="info",
    )


if __name__ == "__main__":
    main()
